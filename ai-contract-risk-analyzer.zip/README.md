# AI Contract Risk Analyzer

Enterprise AI-powered contract risk analysis platform. Upload a contract (PDF/DOCX, including
scanned/image-only PDFs via OCR) and get AI-detected clauses, missing-clause alerts, a
4-dimension risk score, redlines, a negotiation playbook, compliance checks, contract chat, and
more.

> See `PROGRESS.md` for the full, honest breakdown of what's implemented and verified vs. what's
> genuinely gated behind external accounts (Stripe live keys, Google/Microsoft OAuth app
> credentials, a DocuSign developer account) rather than effort.

## Stack

- **Frontend**: Next.js 15, React 19, TypeScript, Tailwind CSS, Recharts
- **Backend**: NestJS, TypeScript
- **Database**: PostgreSQL + Prisma ORM
- **Vector store**: Qdrant (contract chunk embeddings for RAG chat)
- **Queue**: BullMQ + Redis (async analysis, runs as a separate worker process)
- **AI**: OpenAI Responses API + `text-embedding-3-small`
- **OCR**: `tesseract.js` (WASM, no system binary) + `pdf-to-png-converter`
- **Billing**: Stripe (Checkout, Billing Portal, webhooks)
- **Auth**: JWT + refresh-token rotation, Google/Microsoft OAuth (Passport)
- **Export**: `pdfkit` (PDF), `docx` (Word)
- **Infra**: Docker Compose, GitHub Actions CI, pnpm + Turborepo monorepo

## Project structure

```
apps/
  api/     NestJS backend — HTTP API (main.ts) and BullMQ worker (worker.ts) are separate entrypoints
  web/     Next.js frontend
packages/
  db/      Prisma schema + client
.github/workflows/ci.yml
docker-compose.yml
PROGRESS.md
```

## Setup

### 1. Install dependencies

```bash
pnpm install
```

### 2. Start infrastructure

```bash
docker compose up -d postgres redis qdrant
```

(Just the infra services for local dev — see "Running with Docker" below to run the whole stack
containerized instead.)

### 3. Configure environment variables

```bash
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env
```

At minimum, set `OPENAI_API_KEY` and change `JWT_SECRET` to a long random string. Stripe,
Google/Microsoft OAuth, and OCR-language vars are optional — the app boots and works without
them, those specific features just won't be reachable until configured (see `PROGRESS.md`).

### 4. Run database migrations

```bash
cd packages/db
pnpm generate
npx prisma migrate dev --name init
```

### 5. Run the apps

```bash
# from repo root — runs the web app and API (API only enqueues jobs, doesn't process them)
pnpm dev

# in a separate terminal — runs the BullMQ worker that actually does extraction + AI analysis
cd apps/api
pnpm dev:worker
```

Both the API and the worker connect to the same Redis instance, so contract analysis won't
happen unless the worker process is also running — the API will accept uploads and enqueue jobs
either way, but they'll sit in the queue until a worker picks them up.

- API: http://localhost:4000/api/v1
- Web: http://localhost:3000

### 6. Run tests

```bash
cd apps/api
pnpm test
```

27 unit tests covering auth (incl. OAuth login/register branching), risk classification, RAG
chunking, and the AI prompt builders.

## Running with Docker

```bash
docker compose up --build
```

Builds and runs everything: Postgres, Redis, Qdrant, the API, the worker, and the web app. See
`apps/api/Dockerfile` and `apps/web/Dockerfile` for the multi-stage build definitions — the API
image serves both the `api` and `worker` compose services, just with a different command.

## CI

`.github/workflows/ci.yml` runs on every push/PR: install → generate Prisma client → lint →
typecheck + build both apps → run tests → build both Docker images.

## API endpoints

| Method | Path                    | Auth | Description                          |
|--------|-------------------------|------|---------------------------------------|
| POST   | `/api/v1/auth/register` | No   | Create org + owner user               |
| POST   | `/api/v1/auth/login`    | No   | Log in, get access + refresh tokens   |
| POST   | `/api/v1/auth/refresh`  | No   | Rotate refresh token                  |
| GET    | `/api/v1/auth/google`, `/auth/microsoft` | No | Start OAuth flow (redirects to provider) |
| GET    | `/api/v1/auth/google/callback`, `/auth/microsoft/callback` | No | OAuth callback → redirects to frontend with tokens |
| GET    | `/api/v1/contracts`     | Yes  | List org's contracts                  |
| GET    | `/api/v1/contracts/:id` | Yes  | Get contract + AI report + risk score |
| POST   | `/api/v1/contracts/upload` | Yes | Upload PDF/DOCX (OCR'd automatically if scanned), enqueues analysis |
| GET    | `/api/v1/contracts/:id/export/pdf`, `/export/docx` | Yes | Download the AI report as PDF/DOCX |
| GET/POST | `/api/v1/contracts/:id/redlines[/generate]` | Yes | AI-rewritten clauses for HIGH/CRITICAL risks |
| GET/POST | `/api/v1/contracts/:id/negotiation[/generate]` | Yes | Negotiation playbook per high-risk clause |
| GET/POST | `/api/v1/contracts/:id/dates[/extract]` | Yes | Expiry/renewal prediction |
| GET    | `/api/v1/expiry/expiring-soon?withinDays=30` | Yes | Org-wide contracts expiring soon |
| GET/POST | `/api/v1/compliance/frameworks` | Yes | List/create GDPR/HIPAA/ISO 27001 + custom frameworks |
| GET/POST | `/api/v1/contracts/:id/compliance[/check]` | Yes | Run/read compliance check results |
| GET/POST | `/api/v1/contracts/:id/chat` | Yes | RAG chat grounded in the contract text |
| GET    | `/api/v1/analytics/risk-trends`, `/analytics/summary` | Yes | Risk trend dashboard data |
| GET/POST/DELETE | `/api/v1/clause-templates` | Yes | Reusable clause template CRUD |
| GET/POST | `/api/v1/contracts/:id/esignature` | Yes | Create/list e-signature requests |
| POST   | `/api/v1/esignature/:id/mark-signed` | Yes | Mark a manual signature request complete |
| GET/POST | `/api/v1/comparisons` | Yes | List / run a contract-vs-contract comparison |
| GET    | `/api/v1/comparisons/:id` | Yes | Full clause-by-clause diff for a comparison |
| GET    | `/api/v1/notifications`, `/notifications/unread-count` | Yes | List notifications / unread count |
| POST   | `/api/v1/notifications/:id/read`, `/read-all` | Yes | Mark notification(s) read |
| GET    | `/api/v1/billing/subscription` | Yes | Current plan/status |
| POST   | `/api/v1/billing/checkout-session`, `/portal-session` | Yes | Stripe Checkout/Portal redirect URLs |
| POST   | `/api/v1/billing/webhook` | No (Stripe signature) | Stripe webhook receiver |

## Notes

- Uploaded contracts are stored on local disk under `apps/api/storage/contracts/` in this
  version — swap for S3/GCS before production.
- Contract analysis runs asynchronously on a **separate worker process** (Redis-backed BullMQ,
  3 retries with exponential backoff) — see `apps/api/src/worker.ts` / `pnpm start:worker`
  (`pnpm dev:worker` for local dev). The API process only enqueues jobs — it has no analysis code
  loaded at all, so a stuck AI call can never block an HTTP request.
- Scanned (image-only) PDFs are automatically OCR'd before analysis. Only English OCR language
  data ships by default; see `PROGRESS.md` for adding another language.
- RAG chat embeddings are stored in Qdrant and computed lazily on first chat message per
  contract. Qdrant must be running for chat to work.
- E-signature: the `manual` provider works with zero setup. The `docusign` provider requires real
  DocuSign API credentials — see `apps/api/src/esignature/providers/docusign.provider.ts`.
- Billing: requires a Stripe account (free in test mode) and `STRIPE_SECRET_KEY` /
  `STRIPE_WEBHOOK_SECRET` to actually process payments — the webhook signature-verification logic
  itself is fully implemented and unit-verifiable without one (see `PROGRESS.md`).
- OAuth: requires a registered OAuth app with Google/Microsoft for `GOOGLE_CLIENT_ID`/
  `MICROSOFT_CLIENT_ID` etc. — the app boots fine without these set, those routes just aren't
  usable until configured.
- Notifications: a daily cron job (`@nestjs/schedule`, API process only) checks for contracts
  expiring within 30 days and notifies once per contract.
