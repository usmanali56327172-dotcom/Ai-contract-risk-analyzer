import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // "Ink & Brass" — warm near-black ink instead of generic cool tech-slate.
        // Class names stay `slate-*` so every existing bg-slate-900 etc. inherits this
        // automatically; no per-component edits needed.
        slate: {
          50: '#F7F6F3',
          100: '#EDEBE6',
          200: '#D8D5CC',
          300: '#B6B2A6',
          400: '#8A8676',
          500: '#656256',
          600: '#4A473D',
          700: '#35332C',
          800: '#221F1A',
          900: '#16140F',
          950: '#0B0A07',
        },
        // Brass/gold accent replacing generic indigo — evokes a wax seal / gold foil on
        // a legal document. Reserved for brand + primary actions; risk uses red/amber/emerald.
        indigo: {
          50: '#FDF8EC',
          100: '#F8ECC9',
          200: '#F2DDA3',
          300: '#EAC978',
          400: '#E0B84D',
          500: '#D4A017',
          600: '#B8860B',
          700: '#8F660A',
          800: '#6B4D08',
          900: '#4A3506',
          950: '#2E2103',
        },
        risk: {
          low: '#16a34a',
          medium: '#ca8a04',
          high: '#ea580c',
          critical: '#dc2626',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'ui-serif', 'serif'],
        sans: ['var(--font-body)', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['var(--font-data)', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
    },
  },
  plugins: [],
};
export default config;
