'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import { AppHeader } from '@/components/AppHeader';

export default function ComparePage() {
  const router = useRouter();
  const [contracts, setContracts] = useState<any[]>([]);
  const [comparisons, setComparisons] = useState<any[]>([]);
  const [contractAId, setContractAId] = useState('');
  const [contractBId, setContractBId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.listContracts().then((cs) => {
      const analyzed = cs.filter((c: any) => c.status === 'ANALYZED');
      setContracts(analyzed);
      if (analyzed.length >= 2) {
        setContractAId(analyzed[0].id);
        setContractBId(analyzed[1].id);
      }
    }).catch((e) => setError(e.message));
    api.listComparisons().then(setComparisons).catch(() => {});
  }, []);

  async function handleCompare(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const result = await api.compareContracts(contractAId, contractBId);
      router.push(`/compare/${result.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-4xl px-6 py-10">
        <h1 className="font-display mb-1 text-2xl font-semibold">Compare contracts</h1>
        <p className="mb-8 text-sm text-slate-500">
          Diff two analyzed contracts clause by clause and see which one carries more risk.
        </p>

        {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}

        {contracts.length < 2 ? (
          <div className="rounded-xl border border-dashed border-slate-800 p-8 text-center text-slate-500">
            You need at least two fully analyzed contracts to run a comparison.
          </div>
        ) : (
          <form onSubmit={handleCompare} className="mb-10 rounded-xl border border-slate-800 bg-slate-900 p-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm text-slate-400">Contract A</label>
                <select
                  value={contractAId}
                  onChange={(e) => setContractAId(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
                >
                  {contracts.map((c) => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm text-slate-400">Contract B</label>
                <select
                  value={contractBId}
                  onChange={(e) => setContractBId(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
                >
                  {contracts.map((c) => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>
            </div>
            <button
              type="submit"
              disabled={loading || contractAId === contractBId}
              className="mt-4 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
            >
              {loading ? 'Comparing…' : 'Run comparison'}
            </button>
            {contractAId === contractBId && (
              <p className="mt-2 text-xs text-slate-600">Choose two different contracts.</p>
            )}
          </form>
        )}

        <h2 className="mb-3 text-lg font-medium text-slate-300">Past comparisons</h2>
        {comparisons.length === 0 ? (
          <p className="text-sm text-slate-600">No comparisons run yet.</p>
        ) : (
          <div className="space-y-2">
            {comparisons.map((c) => (
              <Link
                key={c.id}
                href={`/compare/${c.id}`}
                className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 px-4 py-3 hover:border-indigo-800"
              >
                <span className="text-sm">
                  {c.contractA.title} <span className="text-slate-600">vs</span> {c.contractB.title}
                </span>
                <span className="font-data text-xs text-slate-500">
                  {new Date(c.createdAt).toLocaleDateString()}
                </span>
              </Link>
            ))}
          </div>
        )}
      </main>
    </>
  );
}
