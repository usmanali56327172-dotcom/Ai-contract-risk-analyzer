'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import { AppHeader } from '@/components/AppHeader';

const CHANGE_STYLES: Record<string, string> = {
  ADDED: 'border-emerald-800 bg-emerald-950 text-emerald-400',
  REMOVED: 'border-red-800 bg-red-950 text-red-400',
  MODIFIED: 'border-amber-800 bg-amber-950 text-amber-400',
  UNCHANGED: 'border-slate-700 bg-slate-800 text-slate-400',
};

export default function ComparisonDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [comparison, setComparison] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.getComparison(id).then(setComparison).catch((e) => setError(e.message));
  }, [id]);

  if (error) return <><AppHeader /><main className="p-10 text-red-300">{error}</main></>;
  if (!comparison) return <><AppHeader /><main className="p-10 text-slate-500">Loading…</main></>;

  const { contractA, contractB, overallSummary, riskDelta, diffs } = comparison;
  const riskierIsB = riskDelta > 0;
  const riskierIsA = riskDelta < 0;

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-4xl px-6 py-10">
        <Link href="/compare" className="font-data text-xs uppercase tracking-wide text-slate-500 hover:text-indigo-400">
          ← Back to comparisons
        </Link>

        <h1 className="font-display mt-4 mb-2 text-2xl font-semibold">
          {contractA.title} <span className="text-slate-600">vs</span> {contractB.title}
        </h1>

        <div className="mb-8 flex items-center gap-3">
          {riskDelta !== 0 && (
            <span className="font-data rounded-full border border-amber-800 bg-amber-950 px-3 py-1 text-xs text-amber-300">
              {riskierIsB ? `${contractB.title} is riskier` : riskierIsA ? `${contractA.title} is riskier` : 'Equal risk'}
              {' '}({riskDelta > 0 ? '+' : ''}{Math.round(riskDelta)} pts)
            </span>
          )}
        </div>

        <section className="mb-8 rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h2 className="mb-2 text-sm font-medium uppercase tracking-wide text-slate-500">Overall summary</h2>
          <p className="text-slate-300">{overallSummary}</p>
        </section>

        <h2 className="mb-3 text-lg font-medium">Clause-by-clause diff</h2>
        <div className="space-y-3">
          {diffs.map((d: any) => (
            <div key={d.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-medium">{d.clauseType}</span>
                <span className={`font-data rounded-full border px-2.5 py-0.5 text-xs ${CHANGE_STYLES[d.changeType]}`}>
                  {d.changeType}
                </span>
              </div>

              {(d.textA || d.textB) && (
                <div className="mb-2 grid gap-2 sm:grid-cols-2">
                  <div className="rounded-lg bg-slate-950 p-2">
                    <p className="mb-1 font-data text-[10px] uppercase tracking-widest text-slate-600">
                      {contractA.title}
                    </p>
                    <p className="text-xs italic text-slate-500">
                      {d.textA ? `"${d.textA}"` : '— not present —'}
                    </p>
                  </div>
                  <div className="rounded-lg bg-slate-950 p-2">
                    <p className="mb-1 font-data text-[10px] uppercase tracking-widest text-slate-600">
                      {contractB.title}
                    </p>
                    <p className="text-xs italic text-slate-500">
                      {d.textB ? `"${d.textB}"` : '— not present —'}
                    </p>
                  </div>
                </div>
              )}

              <p className="text-sm text-slate-400">{d.diffSummary}</p>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
