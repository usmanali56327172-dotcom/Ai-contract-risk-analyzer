'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import { RiskBadge } from '@/components/RiskBadge';
import { AppHeader } from '@/components/AppHeader';

type Tab = 'report' | 'redlines' | 'negotiation' | 'expiry' | 'compliance' | 'chat' | 'esign';

export default function ContractDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [contract, setContract] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('report');

  useEffect(() => {
    api.getContract(id).then(setContract).catch((e) => setError(e.message));
  }, [id]);

  // Analysis now runs asynchronously on a BullMQ worker, so poll while it's in progress.
  useEffect(() => {
    if (contract?.status !== 'PROCESSING') return;
    const interval = setInterval(() => {
      api.getContract(id).then(setContract).catch(() => {});
    }, 3000);
    return () => clearInterval(interval);
  }, [contract?.status, id]);

  if (error) return <><AppHeader /><main className="p-10 text-red-300">{error}</main></>;
  if (!contract) return <><AppHeader /><main className="p-10 text-slate-500">Loading…</main></>;

  const report = contract.aiReports?.[0];
  const risk = contract.riskScores?.[0];

  const tabs: { key: Tab; label: string }[] = [
    { key: 'report', label: 'AI Report' },
    { key: 'redlines', label: 'Redlines' },
    { key: 'negotiation', label: 'Negotiation' },
    { key: 'expiry', label: 'Expiry' },
    { key: 'compliance', label: 'Compliance' },
    { key: 'chat', label: 'Chat' },
    { key: 'esign', label: 'E-Signature' },
  ];

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-4xl px-6 py-10">
      <Link href="/dashboard" className="font-data text-xs uppercase tracking-wide text-slate-500 hover:text-indigo-400">
        ← Back to contracts
      </Link>

      <header className="mt-4 mb-6 flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">{contract.title}</h1>
        {risk && <RiskBadge level={risk.level} />}
      </header>

      <nav className="mb-8 flex flex-wrap gap-1 border-b border-slate-800">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-t-lg px-4 py-2 text-sm ${
              tab === t.key ? 'border-b-2 border-indigo-500 text-slate-100' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </nav>

      {tab === 'report' && <ReportTab contract={contract} report={report} risk={risk} />}
      {tab === 'redlines' && <RedlinesTab contractId={id} hasReport={!!report} />}
      {tab === 'negotiation' && <NegotiationTab contractId={id} hasReport={!!report} />}
      {tab === 'expiry' && <ExpiryTab contractId={id} />}
      {tab === 'compliance' && <ComplianceTab contractId={id} />}
      {tab === 'chat' && <ChatTab contractId={id} />}
      {tab === 'esign' && <ESignTab contractId={id} />}
      </main>
    </>
  );
}

function ReportTab({ contract, report, risk }: any) {
  const latestVersion = contract.versions?.[0];

  if (contract.status === 'PROCESSING') {
    return (
      <p className="rounded-lg bg-slate-900 px-4 py-3 text-slate-400">
        AI analysis is running in the background — this page refreshes automatically…
      </p>
    );
  }
  if (contract.status === 'FAILED') {
    return <p className="rounded-lg bg-red-950 px-4 py-3 text-red-300">Analysis failed for this contract.</p>;
  }
  if (!report) return <p className="text-slate-500">No AI report yet.</p>;

  return (
    <>
      <div className="mb-6 flex justify-end gap-2">
        <button
          onClick={() => api.downloadExport(contract.id, 'pdf', `${contract.title}.pdf`)}
          className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs text-slate-400 hover:bg-slate-800"
        >
          Export PDF
        </button>
        <button
          onClick={() => api.downloadExport(contract.id, 'docx', `${contract.title}.docx`)}
          className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs text-slate-400 hover:bg-slate-800"
        >
          Export DOCX
        </button>
      </div>
      {latestVersion?.ocrUsed && (
        <p className="mb-6 rounded-lg border border-indigo-800 bg-indigo-950/40 px-4 py-2 font-data text-xs text-indigo-300">
          Scanned document — text recovered via OCR at {Math.round(latestVersion.ocrConfidence ?? 0)}% confidence
        </p>
      )}
      {risk && (
        <section className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {[
            { label: 'Legal', value: risk.legalRisk },
            { label: 'Financial', value: risk.financialRisk },
            { label: 'Operational', value: risk.operationalRisk },
            { label: 'Compliance', value: risk.complianceRisk },
          ].map((r) => (
            <div key={r.label} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <p className="text-xs text-slate-500">{r.label} Risk</p>
              <p className="font-data text-xl font-semibold">{r.value}/100</p>
            </div>
          ))}
        </section>
      )}

      <section className="mb-8">
        <h2 className="mb-2 text-lg font-medium">Executive Summary</h2>
        <p className="rounded-xl border border-slate-800 bg-slate-900 p-4 text-slate-300">{report.executiveSummary}</p>
      </section>

      <section className="mb-8">
        <h2 className="mb-2 text-lg font-medium">Detected Clauses</h2>
        <div className="space-y-3">
          {report.clauses?.map((c: any, i: number) => (
            <div key={i} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <div className="mb-1 flex items-center justify-between">
                <span className="font-medium">{c.type}</span>
                <RiskBadge level={c.riskLevel} />
              </div>
              <p className="mb-1 text-sm italic text-slate-500">&ldquo;{c.excerpt}&rdquo;</p>
              <p className="text-sm text-slate-400">{c.explanation}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-8">
        <h2 className="mb-2 text-lg font-medium">Missing Clauses</h2>
        {report.missingClauses?.length ? (
          <ul className="list-inside list-disc space-y-1 text-slate-300">
            {report.missingClauses.map((m: any, i: number) => (
              <li key={i}><span className="font-medium">{m.type}</span> — {m.reason}</li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500">No missing clauses detected.</p>
        )}
      </section>

      <section className="mb-8">
        <h2 className="mb-2 text-lg font-medium">Recommendations</h2>
        <ul className="list-inside list-disc space-y-1 text-slate-300">
          {report.recommendations?.map((r: string, i: number) => <li key={i}>{r}</li>)}
        </ul>
      </section>

      <p className="text-xs text-slate-600">
        Model: {report.model} · Prompt v{report.promptVersion} · Confidence: {Math.round(report.confidenceScore * 100)}%
      </p>
    </>
  );
}

function RedlinesTab({ contractId, hasReport }: { contractId: string; hasReport: boolean }) {
  const [redlines, setRedlines] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.listRedlines(contractId).then(setRedlines).catch(() => {});
  }, [contractId]);

  async function generate() {
    setLoading(true);
    setError(null);
    try {
      const results = await api.generateRedlines(contractId);
      setRedlines(results);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <p className="mb-4 text-sm text-slate-500">
        AI-rewritten versions of every HIGH or CRITICAL risk clause, with rationale for each change.
      </p>
      <button
        onClick={generate}
        disabled={!hasReport || loading}
        className="mb-6 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
      >
        {loading ? 'Generating redlines…' : 'Generate redlines for high-risk clauses'}
      </button>
      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
      <div className="space-y-4">
        {redlines.map((r) => (
          <div key={r.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-medium">{r.clauseType}</span>
              <span className="text-xs text-slate-500">{r.riskReduction}</span>
            </div>
            <p className="mb-2 text-xs text-slate-500">Original: <span className="italic">&ldquo;{r.originalText}&rdquo;</span></p>
            <p className="mb-2 rounded-lg bg-emerald-950/40 p-3 text-sm text-emerald-300">{r.suggestedText}</p>
            <p className="text-sm text-slate-400">{r.rationale}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function NegotiationTab({ contractId, hasReport }: { contractId: string; hasReport: boolean }) {
  const [points, setPoints] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.listNegotiationPoints(contractId).then(setPoints).catch(() => {});
  }, [contractId]);

  async function generate() {
    setLoading(true);
    setError(null);
    try {
      const results = await api.generateNegotiationPlaybook(contractId);
      setPoints(results);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <p className="mb-4 text-sm text-slate-500">
        A negotiation playbook for every high-risk clause: our position, the counter-ask, and a fallback.
      </p>
      <button
        onClick={generate}
        disabled={!hasReport || loading}
        className="mb-6 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
      >
        {loading ? 'Building playbook…' : 'Generate negotiation playbook'}
      </button>
      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
      <div className="space-y-4">
        {points.map((p) => (
          <div key={p.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-medium">{p.clauseType}</span>
              <span className="rounded-full border border-amber-800 bg-amber-950 px-2 py-0.5 text-xs text-amber-300">
                Priority {p.priority}/5
              </span>
            </div>
            <p className="mb-1 text-sm"><span className="text-slate-500">Our position:</span> <span className="text-slate-300">{p.ourPosition}</span></p>
            <p className="mb-1 text-sm"><span className="text-slate-500">Counter-ask:</span> <span className="text-slate-300">{p.counterAsk}</span></p>
            <p className="text-sm"><span className="text-slate-500">Fallback:</span> <span className="text-slate-300">{p.fallback}</span></p>
          </div>
        ))}
      </div>
    </div>
  );
}

function ExpiryTab({ contractId }: { contractId: string }) {
  const [dates, setDates] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.getDates(contractId).then(setDates).catch(() => setDates(null));
  }, [contractId]);

  async function extract() {
    setLoading(true);
    setError(null);
    try {
      setDates(await api.extractDates(contractId));
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        onClick={extract}
        disabled={loading}
        className="mb-6 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
      >
        {loading ? 'Extracting dates…' : dates ? 'Re-extract dates' : 'Extract expiry & renewal info'}
      </button>
      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
      {dates && (
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Effective Date', value: dates.effectiveDate ? new Date(dates.effectiveDate).toLocaleDateString() : '—' },
            { label: 'Expiry Date', value: dates.expiryDate ? new Date(dates.expiryDate).toLocaleDateString() : '—' },
            { label: 'Days Until Expiry', value: dates.daysUntilExpiry ?? '—' },
            { label: 'Renewal Type', value: dates.renewalType },
            { label: 'Auto-Renew', value: dates.autoRenew ? 'Yes' : 'No' },
            { label: 'Notice Period', value: dates.noticePeriodDays ? `${dates.noticePeriodDays} days` : '—' },
          ].map((d) => (
            <div key={d.label} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <p className="text-xs text-slate-500">{d.label}</p>
              <p className="font-medium">{String(d.value)}</p>
            </div>
          ))}
          {dates.extractionNotes && (
            <div className="col-span-2 rounded-xl border border-slate-800 bg-slate-900 p-4">
              <p className="text-xs text-slate-500">Notes</p>
              <p className="text-sm text-slate-400">{dates.extractionNotes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const FRAMEWORK_LABELS: Record<string, string> = { GDPR: 'GDPR', HIPAA: 'HIPAA', ISO27001: 'ISO 27001' };

function ComplianceTab({ contractId }: { contractId: string }) {
  const [frameworks, setFrameworks] = useState<any[]>([]);
  const [selected, setSelected] = useState('GDPR');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.listComplianceFrameworks().then(setFrameworks).catch(() => {});
    api.getComplianceResults(contractId).then(setResults).catch(() => {});
  }, [contractId]);

  async function runCheck() {
    setLoading(true);
    setError(null);
    try {
      await api.runComplianceCheck(contractId, selected);
      setResults(await api.getComplianceResults(contractId));
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  const statusColor: Record<string, string> = {
    PASS: 'text-emerald-400',
    FAIL: 'text-red-400',
    PARTIAL: 'text-amber-400',
    NOT_APPLICABLE: 'text-slate-500',
  };

  return (
    <div>
      <div className="mb-6 flex gap-3">
        <select
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
        >
          {frameworks.map((f) => (
            <option key={f.code} value={f.code}>{FRAMEWORK_LABELS[f.code] || f.name}</option>
          ))}
        </select>
        <button
          onClick={runCheck}
          disabled={loading}
          className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
        >
          {loading ? 'Checking…' : 'Run compliance check'}
        </button>
      </div>
      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
      <div className="space-y-3">
        {results.map((r) => (
          <div key={r.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div className="mb-1 flex items-center justify-between">
              <span className="font-medium">{r.rule?.code}</span>
              <span className={`text-sm font-medium ${statusColor[r.status]}`}>{r.status}</span>
            </div>
            <p className="mb-1 text-sm text-slate-400">{r.rule?.description}</p>
            <p className="mb-1 text-xs italic text-slate-500">Evidence: {r.evidence}</p>
            {r.recommendation && <p className="text-sm text-amber-300">→ {r.recommendation}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

function ChatTab({ contractId }: { contractId: string }) {
  const [messages, setMessages] = useState<any[]>([]);
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.getChatHistory(contractId).then(setMessages).catch(() => {});
  }, [contractId]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!question.trim()) return;
    const q = question;
    setQuestion('');
    setMessages((m) => [...m, { role: 'USER', content: q }]);
    setLoading(true);
    setError(null);
    try {
      const res = await api.askContract(contractId, q);
      setMessages((m) => [...m, { role: 'ASSISTANT', content: res.answer }]);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <p className="mb-4 text-sm text-slate-500">
        Ask questions about this contract. Answers are grounded only in the uploaded document.
      </p>
      <div className="mb-4 max-h-96 space-y-3 overflow-y-auto rounded-xl border border-slate-800 bg-slate-900 p-4">
        {messages.length === 0 && <p className="text-sm text-slate-600">No messages yet — ask something below.</p>}
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'USER' ? 'text-right' : 'text-left'}>
            <span
              className={`inline-block max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                m.role === 'USER' ? 'bg-indigo-600 text-slate-950' : 'bg-slate-800 text-slate-200'
              }`}
            >
              {m.content}
            </span>
          </div>
        ))}
      </div>
      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
      <form onSubmit={send} className="flex gap-2">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="e.g. What's the termination notice period?"
          className="flex-1 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:border-indigo-500"
        />
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
        >
          {loading ? '…' : 'Ask'}
        </button>
      </form>
    </div>
  );
}

function ESignTab({ contractId }: { contractId: string }) {
  const [requests, setRequests] = useState<any[]>([]);
  const [form, setForm] = useState({ signerEmail: '', signerName: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function load() {
    api.listSignatureRequests(contractId).then(setRequests).catch(() => {});
  }
  useEffect(load, [contractId]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await api.createSignatureRequest(contractId, { ...form, provider: 'manual' });
      setForm({ signerEmail: '', signerName: '' });
      load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function markSigned(id: string) {
    await api.markSigned(id);
    load();
  }

  return (
    <div>
      <p className="mb-4 text-sm text-slate-500">
        Manual e-signature workflow: send the contract out-of-band, then mark it signed here. DocuSign
        integration is scaffolded but needs real API credentials to activate — see PROGRESS.md.
      </p>
      <form onSubmit={send} className="mb-6 flex flex-wrap gap-2">
        <input
          type="email"
          required
          placeholder="Signer email"
          value={form.signerEmail}
          onChange={(e) => setForm((f) => ({ ...f, signerEmail: e.target.value }))}
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
        />
        <input
          required
          placeholder="Signer name"
          value={form.signerName}
          onChange={(e) => setForm((f) => ({ ...f, signerName: e.target.value }))}
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
        />
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
        >
          {loading ? 'Sending…' : 'Send for signature'}
        </button>
      </form>
      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
      <div className="space-y-3">
        {requests.map((r) => (
          <div key={r.id} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div>
              <p className="font-medium">{r.signerName} ({r.signerEmail})</p>
              <p className="text-xs text-slate-500">{r.provider} · {r.status}</p>
            </div>
            {r.status === 'SENT' && (
              <button onClick={() => markSigned(r.id)} className="rounded-lg border border-slate-700 px-3 py-1.5 text-sm hover:bg-slate-800">
                Mark signed
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
