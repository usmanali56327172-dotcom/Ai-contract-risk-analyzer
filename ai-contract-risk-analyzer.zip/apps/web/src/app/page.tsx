import Link from 'next/link';

const CLAUSE_TYPES = [
  'Payment', 'Termination', 'Confidentiality', 'IP', 'Data Privacy', 'Liability',
  'Force Majeure', 'Jurisdiction', 'Renewal', 'Warranty', 'Insurance', 'Dispute Resolution',
];

const FEATURES: { title: string; body: string }[] = [
  { title: 'Clause & risk detection', body: 'Every clause is classified and scored across legal, financial, operational, and compliance risk — with a reason attached to each score, not just a number.' },
  { title: 'Missing-clause alerts', body: "Flags what isn't there. A contract with no data-breach notification or no force majeure carve-out is a risk you can't redline if nobody spots the gap first." },
  { title: 'AI redline generator', body: 'Rewrites your highest-risk clauses in place, with the reasoning for each change — the same clause, less exposure.' },
  { title: 'Negotiation assistant', body: 'A prioritized playbook for every risky clause: your position, the counter-ask, and a fallback if it gets pushed back.' },
  { title: 'Contract chat (RAG)', body: 'Ask it anything about the document. Answers are grounded only in what the contract actually says.' },
  { title: 'Expiry & renewal tracking', body: 'Extracts effective dates, notice periods, and auto-renewal terms, so nothing renews itself without you noticing.' },
  { title: 'Compliance checks', body: 'Runs the contract against GDPR, HIPAA, or ISO 27001 — or a rule set your team defines — clause by clause.' },
  { title: 'Multi-language analysis', body: 'Reads the contract in its original language and reports back in English, without skipping substance to get there.' },
  { title: 'Clause library', body: 'Save your best redlined clauses once. Reuse them on every contract that comes after.' },
];

export default function HomePage() {
  return (
    <main>
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="font-display text-lg font-semibold text-slate-100">
          Contract<span className="text-indigo-400">Risk</span>
          <span className="ml-2 font-data text-[10px] uppercase tracking-widest text-slate-500">AI</span>
        </span>
        <div className="flex items-center gap-4">
          <Link href="/login" className="text-sm text-slate-400 hover:text-slate-100">
            Log in
          </Link>
          <Link href="/register" className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500">
            Get started
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="mx-auto grid max-w-6xl gap-12 px-6 pb-20 pt-8 lg:grid-cols-2 lg:items-center lg:gap-8">
        <div>
          <p className="mb-4 font-data text-xs uppercase tracking-widest text-indigo-400">
            Contract review, redlined by AI
          </p>
          <h1 className="font-display text-4xl font-semibold leading-[1.1] tracking-tight text-slate-100 sm:text-5xl">
            Find the clause<br />that costs you later.
          </h1>
          <p className="mt-5 max-w-md text-slate-400">
            Upload a contract. Get every risky clause flagged, scored, and rewritten — plus what's
            silently missing — before you sign anything.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/register" className="rounded-lg bg-indigo-600 px-5 py-2.5 font-medium text-slate-950 hover:bg-indigo-500">
              Analyze your first contract
            </Link>
            <Link href="/login" className="rounded-lg border border-slate-700 px-5 py-2.5 font-medium text-slate-300 hover:bg-slate-900">
              Log in
            </Link>
          </div>

          <div className="mt-10">
            <p className="mb-2 font-data text-[11px] uppercase tracking-widest text-slate-600">Clause types detected</p>
            <div className="flex flex-wrap gap-1.5">
              {CLAUSE_TYPES.map((c) => (
                <span key={c} className="rounded-full border border-slate-800 bg-slate-900 px-2.5 py-1 text-xs text-slate-400">
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Signature element: an actual redline, not stock art */}
        <RedlineMockup />
      </section>

      {/* Feature grid */}
      <section className="border-t border-slate-800 bg-slate-900/40">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <h2 className="font-display text-2xl font-semibold text-slate-100">
            Everything after the upload
          </h2>
          <p className="mt-2 max-w-lg text-slate-500">
            Detection is the first step. Here's what happens once a risk is found.
          </p>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="rounded-xl border border-slate-800 bg-slate-950 p-6">
                <h3 className="font-display text-lg font-medium text-slate-100">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-500">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-6 py-10 text-xs text-slate-600">
        <p>AI Contract Risk Analyzer</p>
      </footer>
    </main>
  );
}

/** The hero's signature moment: a real redline, built from the product's actual mechanic —
 * struck-through original clause, brass-underlined AI rewrite, margin risk badge. */
function RedlineMockup() {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl shadow-black/40">
      <div className="mb-4 flex items-center justify-between border-b border-slate-800 pb-3">
        <span className="font-data text-xs uppercase tracking-widest text-slate-500">
          Clause 8.2 — Limitation of Liability
        </span>
        <span className="rounded-full border border-red-900 bg-red-950 px-2 py-0.5 font-data text-xs text-red-400">
          HIGH
        </span>
      </div>

      <p className="font-data text-[13px] leading-relaxed text-slate-500 line-through decoration-red-500/70">
        In no event shall either party's liability exceed the fees paid in the preceding one (1) month.
      </p>

      <p className="mt-3 rounded-lg bg-indigo-950/50 p-3 font-data text-[13px] leading-relaxed text-indigo-200 underline decoration-indigo-500/70 decoration-2 underline-offset-2">
        In no event shall either party's liability exceed the fees paid in the preceding twelve
        (12) months, except in cases of gross negligence or willful misconduct.
      </p>

      <div className="mt-4 flex items-start gap-2 rounded-lg border border-slate-800 bg-slate-950 p-3">
        <span className="mt-0.5 font-data text-[10px] uppercase tracking-widest text-slate-600">AI</span>
        <p className="text-xs leading-relaxed text-slate-400">
          A one-month cap is unusually low and excludes carve-outs for gross negligence — this
          leaves you exposed on your largest engagements.
        </p>
      </div>

      <div className="mt-4 flex items-center justify-between font-data text-xs text-slate-600">
        <span>Risk reduced: HIGH → LOW</span>
        <span>Confidence 92%</span>
      </div>
    </div>
  );
}
