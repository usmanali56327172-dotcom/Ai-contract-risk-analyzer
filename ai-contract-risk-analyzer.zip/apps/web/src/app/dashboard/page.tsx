'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { RiskBadge } from '@/components/RiskBadge';
import { AppHeader } from '@/components/AppHeader';

export default function DashboardPage() {
  const [contracts, setContracts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listContracts()
      .then(setContracts)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-5xl px-6 py-10">
        <header className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Contracts</h1>
            <p className="text-sm text-slate-500">Every agreement your organization has run through analysis.</p>
          </div>
          <Link href="/upload" className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500">
            Upload contract
          </Link>
        </header>

        {loading && <p className="text-slate-500">Loading…</p>}
        {error && <p className="rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}

        {!loading && contracts.length === 0 && (
          <div className="rounded-xl border border-dashed border-slate-800 p-12 text-center text-slate-500">
            No contracts yet. Upload your first one to see AI risk analysis.
          </div>
        )}

        <div className="grid gap-3">
          {contracts.map((c) => {
            const risk = c.riskScores?.[0];
            return (
              <Link
                key={c.id}
                href={`/contracts/${c.id}`}
                className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 px-5 py-4 transition-colors hover:border-indigo-800"
              >
                <div>
                  <p className="font-medium">{c.title}</p>
                  <p className="font-data text-xs text-slate-500">
                    {c.status} · {new Date(c.createdAt).toLocaleDateString()}
                  </p>
                </div>
                {risk ? <RiskBadge level={risk.level} /> : <span className="text-xs text-slate-600">Pending</span>}
              </Link>
            );
          })}
        </div>
      </main>
    </>
  );
}
