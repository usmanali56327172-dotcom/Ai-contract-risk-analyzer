'use client';

import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { setSession } from '@/lib/api';

function OAuthCallbackInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const accessToken = searchParams.get('accessToken');
    const refreshToken = searchParams.get('refreshToken');

    if (!accessToken || !refreshToken) {
      setError('Sign-in did not return valid tokens. Please try again.');
      return;
    }

    setSession({ accessToken, refreshToken });
    router.replace('/dashboard');
  }, [searchParams, router]);

  if (error) {
    return (
      <div className="text-center">
        <p className="mb-4 text-red-300">{error}</p>
        <a href="/login" className="text-indigo-400 hover:underline">
          Back to login
        </a>
      </div>
    );
  }

  return <p className="text-slate-500">Signing you in…</p>;
}

export default function OAuthCallbackPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <Suspense fallback={<p className="text-slate-500">Signing you in…</p>}>
        <OAuthCallbackInner />
      </Suspense>
    </main>
  );
}
