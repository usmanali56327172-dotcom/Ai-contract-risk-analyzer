'use client';

import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { api } from '@/lib/api';
import { AppHeader } from '@/components/AppHeader';

export default function AnalyticsPage() {
  const [trends, setTrends] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.getRiskTrends(), api.getAnalyticsSummary()])
      .then(([t, s]) => {
        setTrends(t);
        setSummary(s);
      })
      .catch((e) => setError(e.message));
  }, []);

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-5xl px-6 py-10">
      <h1 className="mb-8 text-2xl font-semibold">Risk Trend Dashboard</h1>

      {error && <p className="rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}

      {summary && (
        <section className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {[
            { label: 'Total Contracts', value: summary.totalContracts },
            { label: 'Avg Risk Score', value: `${summary.avgOverallRiskScore}/100` },
            { label: 'High/Critical Risk', value: summary.highRiskContracts },
            { label: 'Expiring in 30 Days', value: summary.expiringWithin30Days },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <p className="text-xs text-slate-500">{s.label}</p>
              <p className="font-data text-xl font-semibold">{s.value}</p>
            </div>
          ))}
        </section>
      )}

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-6">
        <h2 className="mb-4 text-lg font-medium">Average Overall Risk Score by Month</h2>
        {trends.length === 0 ? (
          <p className="text-slate-500">Not enough analyzed contracts yet to show a trend.</p>
        ) : (
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#221F1A" />
                <XAxis dataKey="month" stroke="#8A8676" fontSize={12} />
                <YAxis stroke="#8A8676" fontSize={12} domain={[0, 100]} />
                <Tooltip contentStyle={{ background: '#16140F', border: '1px solid #221F1A' }} />
                <Legend />
                <Line type="monotone" dataKey="avgOverallScore" name="Overall Risk" stroke="#D4A017" strokeWidth={2} />
                <Line type="monotone" dataKey="avgLegalRisk" name="Legal" stroke="#f87171" strokeWidth={1.5} />
                <Line type="monotone" dataKey="avgFinancialRisk" name="Financial" stroke="#fbbf24" strokeWidth={1.5} />
                <Line type="monotone" dataKey="avgOperationalRisk" name="Operational" stroke="#34d399" strokeWidth={1.5} />
                <Line type="monotone" dataKey="avgComplianceRisk" name="Compliance" stroke="#38bdf8" strokeWidth={1.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>
      </main>
    </>
  );
}
