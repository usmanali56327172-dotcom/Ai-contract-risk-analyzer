'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { AppHeader } from '@/components/AppHeader';

const CLAUSE_TYPES = [
  'Payment', 'Termination', 'Confidentiality', 'IntellectualProperty', 'DataPrivacy',
  'Liability', 'ForceMajeure', 'Jurisdiction', 'Renewal', 'Warranty', 'Insurance', 'DisputeResolution',
];

export default function ClauseLibraryPage() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ clauseType: CLAUSE_TYPES[0], title: '', content: '' });
  const [saving, setSaving] = useState(false);

  function load() {
    api.listClauseTemplates().then(setTemplates).catch((e) => setError(e.message));
  }

  useEffect(load, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.createClauseTemplate(form);
      setForm({ clauseType: CLAUSE_TYPES[0], title: '', content: '' });
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await api.deleteClauseTemplate(id);
    load();
  }

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-4xl px-6 py-10">
      <header className="mb-8 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Clause Library</h1>
        <button
          onClick={() => setShowForm((s) => !s)}
          className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500"
        >
          {showForm ? 'Cancel' : '+ New template'}
        </button>
      </header>

      {error && <p className="mb-4 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}

      {showForm && (
        <form onSubmit={handleCreate} className="mb-8 space-y-3 rounded-xl border border-slate-800 bg-slate-900 p-5">
          <div className="flex gap-3">
            <select
              value={form.clauseType}
              onChange={(e) => setForm((f) => ({ ...f, clauseType: e.target.value }))}
              className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            >
              {CLAUSE_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <input
              placeholder="Template title"
              required
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              className="flex-1 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            />
          </div>
          <textarea
            placeholder="Clause text…"
            required
            rows={5}
            value={form.content}
            onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
          />
          <button
            type="submit"
            disabled={saving}
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
          >
            {saving ? 'Saving…' : 'Save template'}
          </button>
        </form>
      )}

      {templates.length === 0 && !showForm && (
        <div className="rounded-xl border border-dashed border-slate-800 p-12 text-center text-slate-500">
          No clause templates yet. Save your best clauses here to reuse across contracts.
        </div>
      )}

      <div className="space-y-3">
        {templates.map((t) => (
          <div key={t.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div className="mb-1 flex items-center justify-between">
              <div>
                <span className="mr-2 rounded-full border border-indigo-800 bg-indigo-950 px-2 py-0.5 text-xs text-indigo-300">
                  {t.clauseType}
                </span>
                <span className="font-medium">{t.title}</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-500">
                <span>Used {t.usageCount}×</span>
                <button onClick={() => handleDelete(t.id)} className="text-red-400 hover:underline">
                  Delete
                </button>
              </div>
            </div>
            <p className="whitespace-pre-wrap text-sm text-slate-400">{t.content}</p>
          </div>
        ))}
      </div>
      </main>
    </>
  );
}
