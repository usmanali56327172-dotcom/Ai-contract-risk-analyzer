'use client';

import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { api } from '@/lib/api';
import { AppHeader } from '@/components/AppHeader';

function BillingInner() {
  const searchParams = useSearchParams();
  const [subscription, setSubscription] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<'checkout' | 'portal' | null>(null);
  const checkoutStatus = searchParams.get('checkout');

  useEffect(() => {
    api.getSubscription().then(setSubscription).catch((e) => setError(e.message));
  }, []);

  async function handleUpgrade() {
    setLoading('checkout');
    setError(null);
    try {
      const priceId = process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE_ID || '';
      if (!priceId) {
        setError('No Stripe price configured — set NEXT_PUBLIC_STRIPE_PRO_PRICE_ID.');
        return;
      }
      const { url } = await api.createCheckoutSession(priceId);
      window.location.href = url;
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(null);
    }
  }

  async function handleManage() {
    setLoading('portal');
    setError(null);
    try {
      const { url } = await api.createPortalSession();
      window.location.href = url;
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(null);
    }
  }

  return (
    <main className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="font-display mb-1 text-2xl font-semibold">Billing</h1>
      <p className="mb-8 text-sm text-slate-500">Manage your organization&apos;s plan and payment method.</p>

      {checkoutStatus === 'success' && (
        <p className="mb-6 rounded-lg border border-emerald-800 bg-emerald-950 px-4 py-2 text-sm text-emerald-300">
          Checkout complete — your plan will update shortly.
        </p>
      )}
      {checkoutStatus === 'cancelled' && (
        <p className="mb-6 rounded-lg border border-amber-800 bg-amber-950 px-4 py-2 text-sm text-amber-300">
          Checkout was cancelled — no changes were made.
        </p>
      )}
      {error && <p className="mb-6 rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}

      {subscription && (
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-wide text-slate-500">Current plan</p>
              <p className="font-display text-xl font-semibold capitalize">{subscription.plan}</p>
            </div>
            <span className="font-data rounded-full border border-slate-700 bg-slate-800 px-3 py-1 text-xs capitalize text-slate-300">
              {subscription.status}
            </span>
          </div>

          {subscription.currentPeriodEnd && (
            <p className="mb-4 text-sm text-slate-500">
              Renews {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
            </p>
          )}

          <div className="flex gap-3">
            {subscription.plan === 'free' ? (
              <button
                onClick={handleUpgrade}
                disabled={loading !== null}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
              >
                {loading === 'checkout' ? 'Redirecting…' : 'Upgrade to Pro'}
              </button>
            ) : (
              <button
                onClick={handleManage}
                disabled={loading !== null}
                className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium hover:bg-slate-800 disabled:opacity-50"
              >
                {loading === 'portal' ? 'Redirecting…' : 'Manage subscription'}
              </button>
            )}
          </div>
        </div>
      )}

      <p className="mt-6 text-xs text-slate-600">
        Billing is powered by Stripe. You&apos;ll be redirected to Stripe&apos;s secure checkout to enter payment details.
      </p>
    </main>
  );
}

export default function BillingPage() {
  return (
    <>
      <AppHeader />
      <Suspense fallback={<main className="p-10 text-slate-500">Loading…</main>}>
        <BillingInner />
      </Suspense>
    </>
  );
}
