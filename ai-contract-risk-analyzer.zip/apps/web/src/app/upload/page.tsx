'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { AppHeader } from '@/components/AppHeader';

export default function UploadPage() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return setError('Please select a PDF or DOCX file');
    setError(null);
    setLoading(true);
    try {
      const contract = await api.uploadContract(file, title || file.name);
      router.push(`/contracts/${contract.id}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <AppHeader />
      <main className="mx-auto max-w-lg px-6 py-16">
        <h1 className="font-display mb-1 text-2xl font-semibold">Upload a contract</h1>
        <p className="mb-6 text-sm text-slate-500">Full clause and risk analysis usually takes under a minute.</p>
        <form onSubmit={handleSubmit} className="space-y-4 rounded-xl border border-slate-800 bg-slate-900 p-8">
          {error && <p className="rounded-md bg-red-950 px-3 py-2 text-sm text-red-300">{error}</p>}
          <div>
            <label className="mb-1 block text-sm text-slate-400">Title (optional)</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Vendor MSA — Acme Corp"
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm text-slate-400">File (PDF or DOCX)</label>
            <input
              type="file"
              accept=".pdf,.docx"
              required
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm file:mr-3 file:rounded-md file:border-0 file:bg-indigo-600 file:px-3 file:py-1.5 file:text-slate-950"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-indigo-600 py-2.5 font-medium text-slate-950 hover:bg-indigo-500 disabled:opacity-50"
          >
            {loading ? 'Uploading…' : 'Upload & analyze'}
          </button>
          <p className="text-xs text-slate-600">
            Scanned documents are automatically run through OCR before analysis — no separate step needed.
          </p>
        </form>
      </main>
    </>
  );
}
