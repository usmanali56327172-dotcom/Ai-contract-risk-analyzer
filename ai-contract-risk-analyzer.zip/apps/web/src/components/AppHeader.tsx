'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { clearSession, api } from '@/lib/api';

const NAV_LINKS = [
  { href: '/dashboard', label: 'Contracts' },
  { href: '/compare', label: 'Compare' },
  { href: '/analytics', label: 'Risk Trends' },
  { href: '/clause-library', label: 'Clause Library' },
  { href: '/billing', label: 'Billing' },
];

export function AppHeader() {
  const pathname = usePathname();
  const router = useRouter();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showPanel, setShowPanel] = useState(false);

  useEffect(() => {
    api.unreadNotificationCount().then(setUnreadCount).catch(() => {});
  }, [pathname]);

  async function togglePanel() {
    const next = !showPanel;
    setShowPanel(next);
    if (next) {
      api.listNotifications().then(setNotifications).catch(() => {});
    }
  }

  async function handleMarkAllRead() {
    await api.markAllNotificationsRead();
    setNotifications((n) => n.map((x) => ({ ...x, read: true })));
    setUnreadCount(0);
  }

  return (
    <header className="border-b border-slate-800 bg-slate-950/95 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        <Link href="/dashboard" className="flex items-baseline gap-2">
          <span className="font-display text-lg font-semibold tracking-tight text-slate-100">
            Contract<span className="text-indigo-400">Risk</span>
          </span>
          <span className="font-data text-[10px] uppercase tracking-widest text-slate-500">AI</span>
        </Link>

        <nav className="flex items-center gap-1">
          {NAV_LINKS.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-md px-3 py-1.5 text-sm transition-colors ${
                  active ? 'bg-slate-900 text-slate-100' : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {link.label}
              </Link>
            );
          })}

          <div className="relative ml-1">
            <button
              onClick={togglePanel}
              className="relative rounded-md border border-slate-700 px-3 py-1.5 text-sm text-slate-400 hover:border-slate-600 hover:text-slate-100"
            >
              🔔
              {unreadCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-red-600 px-1 font-data text-[10px] text-white">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>

            {showPanel && (
              <div className="absolute right-0 top-full z-10 mt-2 w-80 rounded-xl border border-slate-800 bg-slate-900 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2">
                  <span className="text-sm font-medium">Notifications</span>
                  <button onClick={handleMarkAllRead} className="text-xs text-indigo-400 hover:underline">
                    Mark all read
                  </button>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {notifications.length === 0 && (
                    <p className="px-4 py-6 text-center text-sm text-slate-600">No notifications yet.</p>
                  )}
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`border-b border-slate-800/60 px-4 py-3 text-sm ${n.read ? 'opacity-50' : ''}`}
                    >
                      <p className="font-medium text-slate-200">{n.title}</p>
                      <p className="mt-0.5 text-xs text-slate-500">{n.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button
            onClick={() => {
              clearSession();
              router.push('/login');
            }}
            className="ml-1 rounded-md border border-slate-700 px-3 py-1.5 text-sm text-slate-400 hover:border-slate-600 hover:text-slate-100"
          >
            Log out
          </button>
        </nav>
      </div>
    </header>
  );
}
