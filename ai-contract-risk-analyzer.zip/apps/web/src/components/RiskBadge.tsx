const COLORS: Record<string, string> = {
  LOW: 'bg-emerald-950 text-emerald-400 border-emerald-800',
  MEDIUM: 'bg-yellow-950 text-yellow-400 border-yellow-800',
  HIGH: 'bg-orange-950 text-orange-400 border-orange-800',
  CRITICAL: 'bg-red-950 text-red-400 border-red-800',
};

export function RiskBadge({ level }: { level: string }) {
  const cls = COLORS[level] || COLORS.LOW;
  return (
    <span className={`rounded-full border px-2.5 py-0.5 font-data text-xs font-medium tracking-wide ${cls}`}>
      {level}
    </span>
  );
}
