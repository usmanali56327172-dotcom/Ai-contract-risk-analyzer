const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';

function getAccessToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem('acra_access_token');
}

export function setSession(data: { accessToken: string; refreshToken: string }) {
  window.localStorage.setItem('acra_access_token', data.accessToken);
  window.localStorage.setItem('acra_refresh_token', data.refreshToken);
}

export function clearSession() {
  window.localStorage.removeItem('acra_access_token');
  window.localStorage.removeItem('acra_refresh_token');
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getAccessToken();
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(body.message || 'Request failed');
  }
  return res.json();
}

export const api = {
  register: (data: { email: string; password: string; fullName: string; organizationName: string }) =>
    request<{ accessToken: string; refreshToken: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  login: (data: { email: string; password: string }) =>
    request<{ accessToken: string; refreshToken: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  listContracts: () => request<any[]>('/contracts'),
  getContract: (id: string) => request<any>(`/contracts/${id}`),
  uploadContract: (file: File, title: string) => {
    const form = new FormData();
    form.append('file', file);
    form.append('title', title);
    return request<any>('/contracts/upload', { method: 'POST', body: form });
  },

  // Redline generator
  generateRedlines: (contractId: string) => request<any[]>(`/contracts/${contractId}/redlines/generate`, { method: 'POST' }),
  listRedlines: (contractId: string) => request<any[]>(`/contracts/${contractId}/redlines`),

  // Negotiation assistant
  generateNegotiationPlaybook: (contractId: string) =>
    request<any[]>(`/contracts/${contractId}/negotiation/generate`, { method: 'POST' }),
  listNegotiationPoints: (contractId: string) => request<any[]>(`/contracts/${contractId}/negotiation`),

  // Expiry prediction
  extractDates: (contractId: string) => request<any>(`/contracts/${contractId}/dates/extract`, { method: 'POST' }),
  getDates: (contractId: string) => request<any>(`/contracts/${contractId}/dates`),
  expiringSoon: (withinDays = 30) => request<any[]>(`/expiry/expiring-soon?withinDays=${withinDays}`),

  // Compliance checker
  listComplianceFrameworks: () => request<any[]>('/compliance/frameworks'),
  runComplianceCheck: (contractId: string, frameworkCode: string) =>
    request<any[]>(`/contracts/${contractId}/compliance/check`, {
      method: 'POST',
      body: JSON.stringify({ frameworkCode }),
    }),
  getComplianceResults: (contractId: string) => request<any[]>(`/contracts/${contractId}/compliance`),

  // AI chat (RAG)
  getChatHistory: (contractId: string) => request<any[]>(`/contracts/${contractId}/chat`),
  askContract: (contractId: string, question: string) =>
    request<{ answer: string; sourceChunks: string[] }>(`/contracts/${contractId}/chat`, {
      method: 'POST',
      body: JSON.stringify({ question }),
    }),

  // Analytics / risk trends
  getRiskTrends: () => request<any[]>('/analytics/risk-trends'),
  getAnalyticsSummary: () => request<any>('/analytics/summary'),

  // Clause template library
  listClauseTemplates: (clauseType?: string) =>
    request<any[]>(`/clause-templates${clauseType ? `?clauseType=${encodeURIComponent(clauseType)}` : ''}`),
  createClauseTemplate: (data: { clauseType: string; title: string; content: string; tags?: string[] }) =>
    request<any>('/clause-templates', { method: 'POST', body: JSON.stringify(data) }),
  useClauseTemplate: (id: string) => request<any>(`/clause-templates/${id}/use`, { method: 'POST' }),
  deleteClauseTemplate: (id: string) => request<any>(`/clause-templates/${id}`, { method: 'DELETE' }),

  // E-signature
  listSignatureRequests: (contractId: string) => request<any[]>(`/contracts/${contractId}/esignature`),
  createSignatureRequest: (contractId: string, data: { signerEmail: string; signerName: string; provider?: string }) =>
    request<any>(`/contracts/${contractId}/esignature`, { method: 'POST', body: JSON.stringify(data) }),
  markSigned: (requestId: string) => request<any>(`/esignature/${requestId}/mark-signed`, { method: 'POST' }),

  // Contract comparison
  listComparisons: () => request<any[]>('/comparisons'),
  getComparison: (id: string) => request<any>(`/comparisons/${id}`),
  compareContracts: (contractAId: string, contractBId: string) =>
    request<any>('/comparisons', { method: 'POST', body: JSON.stringify({ contractAId, contractBId }) }),

  // Notifications
  listNotifications: () => request<any[]>('/notifications'),
  unreadNotificationCount: () => request<number>('/notifications/unread-count'),
  markNotificationRead: (id: string) => request<any>(`/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: () => request<any>('/notifications/read-all', { method: 'POST' }),

  // Billing
  getSubscription: () => request<any>('/billing/subscription'),
  createCheckoutSession: (priceId: string) =>
    request<{ url: string }>('/billing/checkout-session', { method: 'POST', body: JSON.stringify({ priceId }) }),
  createPortalSession: () => request<{ url: string }>('/billing/portal-session', { method: 'POST' }),

  // Export — needs a Bearer token, so this fetches the file and triggers a browser download
  // rather than using a plain <a href> link (which can't carry the Authorization header).
  downloadExport: async (contractId: string, format: 'pdf' | 'docx', filename: string) => {
    const token = getAccessToken();
    const res = await fetch(`${API_BASE}/contracts/${contractId}/export/${format}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) throw new Error('Export failed');
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  },
};

