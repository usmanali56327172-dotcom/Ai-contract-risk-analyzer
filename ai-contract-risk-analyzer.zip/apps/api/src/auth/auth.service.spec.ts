import { Test } from '@nestjs/testing';
import { JwtModule } from '@nestjs/jwt';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { AuthService } from './auth.service';
import { PrismaService } from '../prisma/prisma.service';

describe('AuthService', () => {
  let authService: AuthService;
  let prisma: {
    user: { findUnique: jest.Mock; create: jest.Mock };
    organization: { create: jest.Mock };
    membership: { findFirst: jest.Mock };
    refreshToken: { create: jest.Mock; findUnique: jest.Mock; update: jest.Mock };
  };

  beforeEach(async () => {
    prisma = {
      user: { findUnique: jest.fn(), create: jest.fn() },
      organization: { create: jest.fn() },
      membership: { findFirst: jest.fn() },
      refreshToken: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn() },
    };

    const moduleRef = await Test.createTestingModule({
      imports: [JwtModule.register({ secret: 'test-secret' })],
      providers: [AuthService, { provide: PrismaService, useValue: prisma }],
    }).compile();

    authService = moduleRef.get(AuthService);
  });

  describe('register', () => {
    it('creates an organization + owner user and returns tokens', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      prisma.organization.create.mockResolvedValue({ id: 'org-1', name: 'Acme', slug: 'acme-abc123' });
      prisma.user.create.mockResolvedValue({ id: 'user-1', email: 'a@b.com', fullName: 'Ada' });
      prisma.refreshToken.create.mockResolvedValue({});

      const result = await authService.register({
        email: 'a@b.com',
        password: 'supersecret123',
        fullName: 'Ada',
        organizationName: 'Acme',
      });

      expect(result.user.email).toBe('a@b.com');
      expect(result.organization.id).toBe('org-1');
      expect(typeof result.accessToken).toBe('string');
      expect(typeof result.refreshToken).toBe('string');

      // the password must never be stored in plaintext
      const createCallArgs = prisma.user.create.mock.calls[0][0];
      expect(createCallArgs.data.passwordHash).not.toBe('supersecret123');
      expect(await bcrypt.compare('supersecret123', createCallArgs.data.passwordHash)).toBe(true);
    });

    it('rejects registration with an email that already exists', async () => {
      prisma.user.findUnique.mockResolvedValue({ id: 'existing-user' });

      await expect(
        authService.register({
          email: 'taken@b.com',
          password: 'supersecret123',
          fullName: 'Ada',
          organizationName: 'Acme',
        }),
      ).rejects.toThrow(ConflictException);
    });
  });

  describe('login', () => {
    it('issues tokens for correct credentials', async () => {
      const passwordHash = await bcrypt.hash('correct-password', 12);
      prisma.user.findUnique.mockResolvedValue({
        id: 'user-1',
        email: 'a@b.com',
        fullName: 'Ada',
        passwordHash,
        memberships: [{ organizationId: 'org-1', role: 'OWNER', organization: { id: 'org-1', name: 'Acme' } }],
      });
      prisma.refreshToken.create.mockResolvedValue({});

      const result = await authService.login({ email: 'a@b.com', password: 'correct-password' });
      expect(result.user.email).toBe('a@b.com');
      expect(typeof result.accessToken).toBe('string');
    });

    it('rejects an incorrect password', async () => {
      const passwordHash = await bcrypt.hash('correct-password', 12);
      prisma.user.findUnique.mockResolvedValue({
        id: 'user-1',
        email: 'a@b.com',
        fullName: 'Ada',
        passwordHash,
        memberships: [{ organizationId: 'org-1', role: 'OWNER', organization: {} }],
      });

      await expect(authService.login({ email: 'a@b.com', password: 'wrong-password' })).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('rejects login for a nonexistent user without leaking which part was wrong', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      await expect(authService.login({ email: 'nobody@b.com', password: 'whatever' })).rejects.toThrow(
        UnauthorizedException,
      );
    });
  });

  describe('refresh', () => {
    it('rotates the refresh token: old one is revoked, a new one is issued', async () => {
      prisma.refreshToken.findUnique.mockResolvedValue({
        id: 'rt-1',
        userId: 'user-1',
        revoked: false,
        expiresAt: new Date(Date.now() + 1000 * 60 * 60),
      });
      prisma.refreshToken.update.mockResolvedValue({});
      prisma.membership.findFirst.mockResolvedValue({ organizationId: 'org-1', role: 'OWNER' });
      prisma.refreshToken.create.mockResolvedValue({});

      const result = await authService.refresh('some-raw-refresh-token');

      expect(prisma.refreshToken.update).toHaveBeenCalledWith({
        where: { id: 'rt-1' },
        data: { revoked: true },
      });
      expect(typeof result.accessToken).toBe('string');
      expect(typeof result.refreshToken).toBe('string');
    });

    it('rejects an expired refresh token', async () => {
      prisma.refreshToken.findUnique.mockResolvedValue({
        id: 'rt-1',
        userId: 'user-1',
        revoked: false,
        expiresAt: new Date(Date.now() - 1000), // already expired
      });

      await expect(authService.refresh('expired-token')).rejects.toThrow(UnauthorizedException);
    });

    it('rejects a revoked refresh token (can\'t be reused after rotation)', async () => {
      prisma.refreshToken.findUnique.mockResolvedValue({
        id: 'rt-1',
        userId: 'user-1',
        revoked: true,
        expiresAt: new Date(Date.now() + 1000 * 60 * 60),
      });

      await expect(authService.refresh('already-used-token')).rejects.toThrow(UnauthorizedException);
    });

    it('rejects an unknown refresh token', async () => {
      prisma.refreshToken.findUnique.mockResolvedValue(null);
      await expect(authService.refresh('not-a-real-token')).rejects.toThrow(UnauthorizedException);
    });
  });

  describe('loginOrRegisterOAuth', () => {
    it('logs in an existing user found by email without creating a new org', async () => {
      prisma.user.findUnique.mockResolvedValue({
        id: 'user-1',
        email: 'existing@b.com',
        memberships: [{ organizationId: 'org-1', role: 'OWNER' }],
      });
      prisma.refreshToken.create.mockResolvedValue({});

      const result = await authService.loginOrRegisterOAuth('existing@b.com', 'Existing User');

      expect(prisma.organization.create).not.toHaveBeenCalled();
      expect(typeof result.accessToken).toBe('string');
    });

    it('creates a personal organization for a brand-new OAuth user', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      prisma.organization.create.mockResolvedValue({ id: 'org-new', name: "Ada's Organization" });
      prisma.user.create.mockResolvedValue({ id: 'user-new', email: 'new@b.com', fullName: 'Ada' });
      prisma.refreshToken.create.mockResolvedValue({});

      const result = await authService.loginOrRegisterOAuth('new@b.com', 'Ada');

      expect(prisma.organization.create).toHaveBeenCalled();
      expect(prisma.user.create).toHaveBeenCalled();
      // OAuth users still get a hashed (unusable) password, never a plaintext one
      const createArgs = prisma.user.create.mock.calls[0][0];
      expect(createArgs.data.passwordHash).toBeDefined();
      expect(createArgs.data.passwordHash.startsWith('$2b$')).toBe(true); // bcrypt hash prefix
      expect(typeof result.accessToken).toBe('string');
    });
  });
});
