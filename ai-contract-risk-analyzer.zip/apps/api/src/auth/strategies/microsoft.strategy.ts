import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
// @ts-ignore — passport-microsoft ships its own runtime but the @types package models it
// slightly differently; the shape used below matches the actual library at runtime.
import { Strategy } from 'passport-microsoft';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '../auth.service';

@Injectable()
export class MicrosoftStrategy extends PassportStrategy(Strategy, 'microsoft') {
  constructor(
    config: ConfigService,
    private readonly authService: AuthService,
  ) {
    super({
      clientID: config.get<string>('MICROSOFT_CLIENT_ID', 'not-configured'),
      clientSecret: config.get<string>('MICROSOFT_CLIENT_SECRET', 'not-configured'),
      callbackURL: config.get<string>(
        'MICROSOFT_CALLBACK_URL',
        'http://localhost:4000/api/v1/auth/microsoft/callback',
      ),
      scope: ['user.read'],
    });
  }

  async validate(
    _accessToken: string,
    _refreshToken: string,
    profile: any,
    done: (err: any, user?: any) => void,
  ): Promise<void> {
    const email = profile.emails?.[0]?.value ?? profile._json?.mail ?? profile._json?.userPrincipalName;
    const fullName = profile.displayName;

    if (!email) {
      done(new Error('Microsoft did not return an email address'), undefined);
      return;
    }

    const tokens = await this.authService.loginOrRegisterOAuth(email, fullName);
    done(null, tokens);
  }
}
