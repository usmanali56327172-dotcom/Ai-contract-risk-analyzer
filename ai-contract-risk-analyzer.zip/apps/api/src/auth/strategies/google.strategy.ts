import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy, VerifyCallback } from 'passport-google-oauth20';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '../auth.service';

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor(
    config: ConfigService,
    private readonly authService: AuthService,
  ) {
    super({
      // Falls back to placeholder values so the app can still boot without Google OAuth
      // configured — the /auth/google route will just fail clearly if actually hit unconfigured.
      clientID: config.get<string>('GOOGLE_CLIENT_ID', 'not-configured'),
      clientSecret: config.get<string>('GOOGLE_CLIENT_SECRET', 'not-configured'),
      callbackURL: config.get<string>('GOOGLE_CALLBACK_URL', 'http://localhost:4000/api/v1/auth/google/callback'),
      scope: ['email', 'profile'],
    });
  }

  async validate(
    _accessToken: string,
    _refreshToken: string,
    profile: any,
    done: VerifyCallback,
  ): Promise<void> {
    const email = profile.emails?.[0]?.value;
    const fullName = profile.displayName;

    if (!email) {
      done(new Error('Google did not return an email address'), undefined);
      return;
    }

    const tokens = await this.authService.loginOrRegisterOAuth(email, fullName);
    done(null, tokens);
  }
}
