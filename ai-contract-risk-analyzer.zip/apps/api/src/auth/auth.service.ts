import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterDto, LoginDto } from './dto/auth.dto';

const ACCESS_TOKEN_TTL = '15m';
const REFRESH_TOKEN_TTL_DAYS = 30;

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  private async issueTokens(userId: string, orgId: string, role: string) {
    const accessToken = this.jwt.sign(
      { sub: userId, orgId, role },
      { expiresIn: ACCESS_TOKEN_TTL },
    );

    const rawRefresh = crypto.randomBytes(48).toString('hex');
    const tokenHash = hashToken(rawRefresh);
    const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000);

    await this.prisma.refreshToken.create({
      data: { userId, tokenHash, expiresAt },
    });

    return { accessToken, refreshToken: rawRefresh };
  }

  async register(dto: RegisterDto) {
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) throw new ConflictException('Email already registered');

    const passwordHash = await bcrypt.hash(dto.password, 12);
    const slug = dto.organizationName.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50);

    const org = await this.prisma.organization.create({
      data: { name: dto.organizationName, slug: `${slug}-${crypto.randomBytes(3).toString('hex')}` },
    });

    const user = await this.prisma.user.create({
      data: {
        email: dto.email,
        passwordHash,
        fullName: dto.fullName,
        memberships: {
          create: { organizationId: org.id, role: 'OWNER' },
        },
      },
    });

    const tokens = await this.issueTokens(user.id, org.id, 'OWNER');
    return { user: { id: user.id, email: user.email, fullName: user.fullName }, organization: org, ...tokens };
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: { memberships: { include: { organization: true } } },
    });
    if (!user) throw new UnauthorizedException('Invalid credentials');

    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    const membership = user.memberships[0];
    if (!membership) throw new UnauthorizedException('No organization membership found');

    const tokens = await this.issueTokens(user.id, membership.organizationId, membership.role);
    return {
      user: { id: user.id, email: user.email, fullName: user.fullName },
      organization: membership.organization,
      ...tokens,
    };
  }

  async refresh(rawRefresh: string) {
    const tokenHash = hashToken(rawRefresh);
    const record = await this.prisma.refreshToken.findUnique({ where: { tokenHash } });

    if (!record || record.revoked || record.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    // Rotate: revoke old, issue new
    await this.prisma.refreshToken.update({ where: { id: record.id }, data: { revoked: true } });

    const membership = await this.prisma.membership.findFirst({ where: { userId: record.userId } });
    if (!membership) throw new UnauthorizedException('No organization membership found');

    return this.issueTokens(record.userId, membership.organizationId, membership.role);
  }

  /**
   * Called by the Google/Microsoft OAuth strategies after the provider confirms the user's
   * identity. If the email matches an existing user, logs them into their first organization —
   * this is how OAuth "just works" for someone who originally signed up with a password. If it's
   * a new email, creates a personal organization for them (same shape as a manual registration).
   *
   * OAuth-only users still get a passwordHash — a random one they'll never see or use — so the
   * schema doesn't need a nullable password column just for this one flow.
   */
  async loginOrRegisterOAuth(email: string, fullName: string) {
    const existing = await this.prisma.user.findUnique({
      where: { email },
      include: { memberships: true },
    });

    if (existing) {
      const membership = existing.memberships[0];
      if (!membership) throw new UnauthorizedException('No organization membership found');
      return this.issueTokens(existing.id, membership.organizationId, membership.role);
    }

    const unusablePassword = crypto.randomBytes(32).toString('hex');
    const passwordHash = await bcrypt.hash(unusablePassword, 12);
    const orgName = `${fullName || email.split('@')[0]}'s Organization`;
    const slug = orgName.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50);

    const org = await this.prisma.organization.create({
      data: { name: orgName, slug: `${slug}-${crypto.randomBytes(3).toString('hex')}` },
    });

    const user = await this.prisma.user.create({
      data: {
        email,
        passwordHash,
        fullName: fullName || email.split('@')[0],
        memberships: { create: { organizationId: org.id, role: 'OWNER' } },
      },
    });

    return this.issueTokens(user.id, org.id, 'OWNER');
  }
}
