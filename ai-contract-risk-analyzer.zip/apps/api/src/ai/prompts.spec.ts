import { buildAnalysisPrompt, CLAUSE_TYPES } from './prompts';

describe('buildAnalysisPrompt', () => {
  it('includes every supported clause type', () => {
    const prompt = buildAnalysisPrompt('This is a test contract.');
    for (const clauseType of CLAUSE_TYPES) {
      expect(prompt).toContain(clauseType);
    }
  });

  it('embeds the contract text verbatim', () => {
    const text = 'UNIQUE_MARKER_12345 the parties agree to nothing in particular.';
    const prompt = buildAnalysisPrompt(text);
    expect(prompt).toContain('UNIQUE_MARKER_12345');
  });

  it('truncates extremely long contract text to 100k characters', () => {
    const longText = 'x'.repeat(200_000);
    const prompt = buildAnalysisPrompt(longText);
    // the prompt should not contain the full 200k-character run of x's
    const xRun = prompt.match(/x+/)?.[0] ?? '';
    expect(xRun.length).toBeLessThanOrEqual(100_000);
  });

  it('requests JSON-only output with no markdown fences', () => {
    const prompt = buildAnalysisPrompt('sample');
    expect(prompt).toMatch(/ONLY valid JSON/i);
  });

  it('asks for a detected language field to support multi-language contracts', () => {
    const prompt = buildAnalysisPrompt('sample');
    expect(prompt).toContain('detectedLanguage');
  });
});
