export const CONTRACT_ANALYSIS_PROMPT_VERSION = 'v1.0.0';

export const CLAUSE_TYPES = [
  'Payment',
  'Termination',
  'Confidentiality',
  'IntellectualProperty',
  'DataPrivacy',
  'Liability',
  'ForceMajeure',
  'Jurisdiction',
  'Renewal',
  'Warranty',
  'Insurance',
  'DisputeResolution',
] as const;

export function buildAnalysisPrompt(contractText: string): string {
  return `You are a senior contract-risk analyst who works across languages. Analyze the following contract text — it may be written in ANY language — and return ONLY valid JSON (no markdown fences, no preamble) matching exactly this shape:

{
  "detectedLanguage": string (ISO 639-1 code, e.g. "en", "es", "fr", "ur", "ar", "zh"),
  "executiveSummary": string (write this in English regardless of the contract's original language, so it's usable on an English-language dashboard),
  "clauses": [
    { "type": one of ${JSON.stringify(CLAUSE_TYPES)}, "excerpt": string (quote in the ORIGINAL language of the contract), "riskLevel": "LOW"|"MEDIUM"|"HIGH"|"CRITICAL", "confidence": number (0-1), "explanation": string (in English) }
  ],
  "missingClauses": [ { "type": string, "reason": string (in English) } ],
  "risks": {
    "legalRisk": number (0-100),
    "financialRisk": number (0-100),
    "operationalRisk": number (0-100),
    "complianceRisk": number (0-100)
  },
  "overallRiskScore": number (0-100),
  "riskLevel": "LOW"|"MEDIUM"|"HIGH"|"CRITICAL",
  "recommendations": [string] (in English),
  "confidenceScore": number (0-1)
}

Identify clauses only from this list: ${CLAUSE_TYPES.join(', ')}. Flag any of these clause types that are entirely absent from the contract as missing clauses. Analyze the substance of the contract fully in its original language — do not skip or simplify analysis just because it isn't in English — but write all summary/explanation/recommendation text in English. Be specific and concrete; do not hedge with generic disclaimers.

CONTRACT TEXT:
"""
${contractText.slice(0, 100000)}
"""`;
}
