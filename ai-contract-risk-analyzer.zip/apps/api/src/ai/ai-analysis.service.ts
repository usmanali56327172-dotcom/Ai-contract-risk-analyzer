import { Injectable, Logger, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { buildAnalysisPrompt, CONTRACT_ANALYSIS_PROMPT_VERSION } from './prompts';

export interface ClauseResult {
  type: string;
  excerpt: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  confidence: number;
  explanation: string;
}

export interface MissingClauseResult {
  type: string;
  reason: string;
}

export interface ContractAnalysisResult {
  detectedLanguage: string;
  executiveSummary: string;
  clauses: ClauseResult[];
  missingClauses: MissingClauseResult[];
  risks: {
    legalRisk: number;
    financialRisk: number;
    operationalRisk: number;
    complianceRisk: number;
  };
  overallRiskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  recommendations: string[];
  confidenceScore: number;
  model: string;
  promptVersion: string;
}

@Injectable()
export class AiAnalysisService {
  private readonly logger = new Logger(AiAnalysisService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(private readonly config: ConfigService) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  async analyzeContract(contractText: string): Promise<ContractAnalysisResult> {
    const prompt = buildAnalysisPrompt(contractText);

    let response;
    try {
      response = await this.client.responses.create({
        model: this.model,
        input: prompt,
        temperature: 0.1,
      });
    } catch (err) {
      this.logger.error('OpenAI analysis call failed', err as Error);
      throw new InternalServerErrorException('AI analysis provider error');
    }

    const raw = response.output_text?.trim() ?? '';
    const cleaned = raw.replace(/^```json\s*/i, '').replace(/```$/, '').trim();

    let parsed: any;
    try {
      parsed = JSON.parse(cleaned);
    } catch (err) {
      this.logger.error('Failed to parse AI response as JSON', err as Error);
      throw new InternalServerErrorException('AI response could not be parsed');
    }

    return {
      detectedLanguage: parsed.detectedLanguage || 'en',
      executiveSummary: parsed.executiveSummary,
      clauses: parsed.clauses ?? [],
      missingClauses: parsed.missingClauses ?? [],
      risks: parsed.risks,
      overallRiskScore: parsed.overallRiskScore,
      riskLevel: parsed.riskLevel,
      recommendations: parsed.recommendations ?? [],
      confidenceScore: parsed.confidenceScore ?? 0,
      model: this.model,
      promptVersion: CONTRACT_ANALYSIS_PROMPT_VERSION,
    };
  }
}
