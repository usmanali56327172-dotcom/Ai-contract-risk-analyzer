import { Injectable, NotFoundException } from '@nestjs/common';
import * as fs from 'fs/promises';
import { PrismaService } from '../prisma/prisma.service';
import { ManualESignatureProvider } from './providers/manual-esignature.provider';
import { DocuSignProvider } from './providers/docusign.provider';
import { ESignatureProvider } from './providers/esignature-provider.interface';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class ESignatureService {
  private readonly providers: Record<string, ESignatureProvider>;

  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
    manualProvider: ManualESignatureProvider,
    docuSignProvider: DocuSignProvider,
  ) {
    this.providers = {
      manual: manualProvider,
      docusign: docuSignProvider,
    };
  }

  async listForContract(contractId: string) {
    return this.prisma.eSignatureRequest.findMany({
      where: { contractId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async createRequest(
    orgId: string,
    contractId: string,
    params: { signerEmail: string; signerName: string; provider?: string },
  ) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: { versions: { orderBy: { versionNum: 'desc' }, take: 1 } },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }

    const providerName = params.provider || 'manual';
    const provider = this.providers[providerName];

    const version = contract.versions[0];
    const fileBuffer = version ? await fs.readFile(version.storagePath).catch(() => Buffer.from('')) : Buffer.from('');

    const result = await provider.createRequest({
      contractTitle: contract.title,
      fileBuffer,
      fileName: version?.fileName ?? 'contract',
      signerEmail: params.signerEmail,
      signerName: params.signerName,
    });

    return this.prisma.eSignatureRequest.create({
      data: {
        contractId,
        provider: providerName,
        status: result.status,
        externalId: result.externalId,
        signerEmail: params.signerEmail,
        signerName: params.signerName,
        sentAt: result.status === 'SENT' ? new Date() : null,
      },
    });
  }

  /** Manually mark a signature request as signed — the counterpart to a real provider's webhook. */
  async markSigned(orgId: string, requestId: string) {
    const request = await this.prisma.eSignatureRequest.findUnique({
      where: { id: requestId },
      include: { contract: true },
    });
    if (!request || request.contract.organizationId !== orgId) {
      throw new NotFoundException('Signature request not found');
    }

    const updated = await this.prisma.eSignatureRequest.update({
      where: { id: requestId },
      data: { status: 'SIGNED', completedAt: new Date() },
    });

    await this.notifications.create({
      organizationId: orgId,
      type: 'ESIGNATURE_COMPLETED',
      title: `"${request.contract.title}" was signed`,
      message: `${request.signerName} (${request.signerEmail}) signed the contract.`,
      metadata: { contractId: request.contractId },
    });

    return updated;
  }
}
