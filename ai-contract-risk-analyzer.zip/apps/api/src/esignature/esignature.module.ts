import { Module } from '@nestjs/common';
import { ESignatureController } from './esignature.controller';
import { ESignatureService } from './esignature.service';
import { ManualESignatureProvider } from './providers/manual-esignature.provider';
import { DocuSignProvider } from './providers/docusign.provider';
import { AuthModule } from '../auth/auth.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [AuthModule, NotificationsModule],
  controllers: [ESignatureController],
  providers: [ESignatureService, ManualESignatureProvider, DocuSignProvider],
})
export class ESignatureModule {}
