export interface CreateSignatureRequestParams {
  contractTitle: string;
  fileBuffer: Buffer;
  fileName: string;
  signerEmail: string;
  signerName: string;
}

export interface CreateSignatureRequestResult {
  externalId: string | null;
  status: 'DRAFT' | 'SENT';
}

/**
 * Adapter interface so real e-signature providers (DocuSign, HelloSign/Dropbox Sign, Adobe Sign)
 * can be plugged in without changing the service or controller layer.
 */
export interface ESignatureProvider {
  readonly providerName: string;
  createRequest(params: CreateSignatureRequestParams): Promise<CreateSignatureRequestResult>;
}
