import { Injectable } from '@nestjs/common';
import {
  ESignatureProvider,
  CreateSignatureRequestParams,
  CreateSignatureRequestResult,
} from './esignature-provider.interface';

/**
 * "Manual" workflow: no external e-signature vendor involved. The org sends the contract
 * out-of-band (email, in person) and marks it signed themselves via the mark-signed endpoint.
 * This is the default provider so the feature works out of the box without any third-party
 * account or API key.
 */
@Injectable()
export class ManualESignatureProvider implements ESignatureProvider {
  readonly providerName = 'manual';

  async createRequest(_params: CreateSignatureRequestParams): Promise<CreateSignatureRequestResult> {
    return { externalId: null, status: 'SENT' };
  }
}
