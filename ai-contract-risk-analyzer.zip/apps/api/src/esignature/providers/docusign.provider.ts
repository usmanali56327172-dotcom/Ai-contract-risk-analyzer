import { Injectable, NotImplementedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  ESignatureProvider,
  CreateSignatureRequestParams,
  CreateSignatureRequestResult,
} from './esignature-provider.interface';

/**
 * Real DocuSign integration requires a DocuSign developer account: an integration key,
 * a user/account ID, and either JWT-grant or auth-code-grant credentials, plus the
 * `docusign-esign` SDK. None of that exists in this sandbox, so rather than faking a response,
 * this adapter fails loudly and tells you exactly what to configure. Once you have real
 * DocuSign credentials, implement `createRequest` here using the DocuSign eSignature REST API
 * (POST /v2.1/accounts/{accountId}/envelopes) and wire the env vars below.
 *
 * Required env vars once you have a DocuSign account:
 *   DOCUSIGN_INTEGRATION_KEY, DOCUSIGN_USER_ID, DOCUSIGN_ACCOUNT_ID, DOCUSIGN_PRIVATE_KEY,
 *   DOCUSIGN_BASE_URL (e.g. https://demo.docusign.net/restapi for the sandbox environment)
 */
@Injectable()
export class DocuSignProvider implements ESignatureProvider {
  readonly providerName = 'docusign';

  constructor(private readonly config: ConfigService) {}

  async createRequest(_params: CreateSignatureRequestParams): Promise<CreateSignatureRequestResult> {
    const integrationKey = this.config.get<string>('DOCUSIGN_INTEGRATION_KEY');
    if (!integrationKey) {
      throw new NotImplementedException(
        'DocuSign is not configured. Set DOCUSIGN_INTEGRATION_KEY, DOCUSIGN_USER_ID, ' +
          'DOCUSIGN_ACCOUNT_ID, DOCUSIGN_PRIVATE_KEY, and DOCUSIGN_BASE_URL, then implement the ' +
          'envelope-creation call in DocuSignProvider.createRequest(). Use the "manual" provider ' +
          'until then.',
      );
    }

    // Real implementation would go here, using the docusign-esign SDK to create and send an
    // envelope, then return its envelopeId as externalId.
    throw new NotImplementedException('DocuSign envelope creation is not yet implemented.');
  }
}
