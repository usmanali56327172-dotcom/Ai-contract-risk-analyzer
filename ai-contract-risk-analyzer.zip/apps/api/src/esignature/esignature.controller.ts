import { Controller, Get, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ESignatureService } from './esignature.service';
import { CreateSignatureRequestDto } from './dto/esignature.dto';

@Controller()
@UseGuards(JwtAuthGuard)
export class ESignatureController {
  constructor(private readonly esignatureService: ESignatureService) {}

  @Get('contracts/:contractId/esignature')
  list(@Param('contractId') contractId: string) {
    return this.esignatureService.listForContract(contractId);
  }

  @Post('contracts/:contractId/esignature')
  create(@Req() req: any, @Param('contractId') contractId: string, @Body() dto: CreateSignatureRequestDto) {
    return this.esignatureService.createRequest(req.user.orgId, contractId, dto);
  }

  @Post('esignature/:requestId/mark-signed')
  markSigned(@Req() req: any, @Param('requestId') requestId: string) {
    return this.esignatureService.markSigned(req.user.orgId, requestId);
  }
}
