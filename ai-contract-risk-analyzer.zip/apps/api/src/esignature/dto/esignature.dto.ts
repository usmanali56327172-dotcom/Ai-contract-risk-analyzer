import { IsEmail, IsString, IsOptional, IsIn } from 'class-validator';

export class CreateSignatureRequestDto {
  @IsEmail()
  signerEmail: string;

  @IsString()
  signerName: string;

  @IsOptional()
  @IsIn(['manual', 'docusign'])
  provider?: 'manual' | 'docusign';
}
