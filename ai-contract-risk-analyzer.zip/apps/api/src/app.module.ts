import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { APP_GUARD } from '@nestjs/core';
import { PrismaModule } from './prisma/prisma.module';
import { QueueModule } from './queue/queue.module';
import { AuthModule } from './auth/auth.module';
import { ContractsModule } from './contracts/contracts.module';
import { AiModule } from './ai/ai.module';
import { RedlineModule } from './redline/redline.module';
import { NegotiationModule } from './negotiation/negotiation.module';
import { ExpiryModule } from './expiry/expiry.module';
import { ComplianceModule } from './compliance/compliance.module';
import { RagModule } from './rag/rag.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { ClauseTemplateModule } from './clause-templates/clause-template.module';
import { ESignatureModule } from './esignature/esignature.module';
import { ComparisonModule } from './comparison/comparison.module';
import { ExportModule } from './export/export.module';
import { NotificationsModule } from './notifications/notifications.module';
import { BillingModule } from './billing/billing.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    // Cron jobs (e.g. expiring-contract notifications) only run in the API process — the worker
    // process intentionally does not import ScheduleModule, so a job never fires twice.
    ScheduleModule.forRoot(),
    PrismaModule,
    QueueModule,
    AuthModule,
    ContractsModule,
    AiModule,
    RedlineModule,
    NegotiationModule,
    ExpiryModule,
    ComplianceModule,
    RagModule,
    AnalyticsModule,
    ClauseTemplateModule,
    ESignatureModule,
    ComparisonModule,
    ExportModule,
    NotificationsModule,
    BillingModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
