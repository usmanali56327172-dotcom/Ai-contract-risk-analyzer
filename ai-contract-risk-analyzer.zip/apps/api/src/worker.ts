import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';
import { WorkerModule } from './worker.module';

async function bootstrap() {
  const logger = new Logger('Worker');
  const app = await NestFactory.createApplicationContext(WorkerModule, {
    // No HTTP server is started — this process only consumes the BullMQ queue.
    logger: ['log', 'warn', 'error'],
  });

  logger.log('Contract analysis worker started and listening for jobs');

  const shutdown = async (signal: string) => {
    logger.log(`Received ${signal}, shutting down worker gracefully…`);
    await app.close();
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

bootstrap();
