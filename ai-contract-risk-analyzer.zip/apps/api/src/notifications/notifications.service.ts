import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

export type NotificationType =
  | 'CONTRACT_ANALYZED'
  | 'CONTRACT_EXPIRING'
  | 'COMPLIANCE_FAILED'
  | 'ESIGNATURE_COMPLETED'
  | 'COMPARISON_COMPLETED'
  | 'BILLING_UPDATED';

@Injectable()
export class NotificationsService {
  constructor(private readonly prisma: PrismaService) {}

  /** Creates a notification. Pass userId to target one person, or omit for an org-wide notice. */
  async create(params: {
    organizationId: string;
    userId?: string | null;
    type: NotificationType;
    title: string;
    message: string;
    metadata?: Record<string, unknown>;
  }) {
    return this.prisma.notification.create({
      data: {
        organizationId: params.organizationId,
        userId: params.userId ?? null,
        type: params.type,
        title: params.title,
        message: params.message,
        metadata: params.metadata ?? undefined,
      },
    });
  }

  /** A user sees org-wide notifications plus anything addressed specifically to them. */
  async listForUser(orgId: string, userId: string, limit = 50) {
    return this.prisma.notification.findMany({
      where: {
        organizationId: orgId,
        OR: [{ userId: null }, { userId }],
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }

  async unreadCount(orgId: string, userId: string) {
    return this.prisma.notification.count({
      where: {
        organizationId: orgId,
        OR: [{ userId: null }, { userId }],
        read: false,
      },
    });
  }

  async markRead(orgId: string, id: string) {
    return this.prisma.notification.updateMany({
      where: { id, organizationId: orgId },
      data: { read: true },
    });
  }

  async markAllRead(orgId: string, userId: string) {
    return this.prisma.notification.updateMany({
      where: { organizationId: orgId, OR: [{ userId: null }, { userId }], read: false },
      data: { read: true },
    });
  }
}
