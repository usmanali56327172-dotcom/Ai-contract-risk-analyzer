import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from './notifications.service';

const EXPIRY_WARNING_WINDOW_DAYS = 30;

@Injectable()
export class ExpiryNotificationJob {
  private readonly logger = new Logger(ExpiryNotificationJob.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
  ) {}

  @Cron(CronExpression.EVERY_DAY_AT_9AM)
  async notifyExpiringContracts(): Promise<void> {
    const cutoff = new Date(Date.now() + EXPIRY_WARNING_WINDOW_DAYS * 24 * 60 * 60 * 1000);

    const candidates = await this.prisma.contractDates.findMany({
      where: {
        notifiedExpiringSoon: false,
        expiryDate: { lte: cutoff, gte: new Date() },
      },
      include: { contract: { select: { id: true, title: true, organizationId: true } } },
    });

    for (const candidate of candidates) {
      const daysUntilExpiry = Math.ceil(
        (candidate.expiryDate!.getTime() - Date.now()) / (1000 * 60 * 60 * 24),
      );

      await this.notifications.create({
        organizationId: candidate.contract.organizationId,
        type: 'CONTRACT_EXPIRING',
        title: `"${candidate.contract.title}" expires in ${daysUntilExpiry} days`,
        message: candidate.autoRenew
          ? `This contract will auto-renew unless notice is given${candidate.noticePeriodDays ? ` (${candidate.noticePeriodDays} days notice required)` : ''}.`
          : `This contract expires on ${candidate.expiryDate!.toLocaleDateString()} and does not auto-renew.`,
        metadata: { contractId: candidate.contract.id },
      });

      await this.prisma.contractDates.update({
        where: { id: candidate.id },
        data: { notifiedExpiringSoon: true },
      });
    }

    if (candidates.length > 0) {
      this.logger.log(`Sent ${candidates.length} contract-expiring notification(s)`);
    }
  }
}
