import { Module } from '@nestjs/common';
import { NotificationsController } from './notifications.controller';
import { NotificationsService } from './notifications.service';
import { ExpiryNotificationJob } from './expiry-notification.job';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [AuthModule],
  controllers: [NotificationsController],
  providers: [NotificationsService, ExpiryNotificationJob],
  exports: [NotificationsService],
})
export class NotificationsModule {}
