import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { PrismaModule } from './prisma/prisma.module';
import { QueueModule, CONTRACT_ANALYSIS_QUEUE } from './queue/queue.module';
import { AiModule } from './ai/ai.module';
import { OcrModule } from './ocr/ocr.module';
import { ContractsProcessor } from './contracts/contracts.processor';
import { DocumentExtractionService } from './contracts/document-extraction.service';
import { NotificationsService } from './notifications/notifications.service';

/**
 * This is a separate, deployable unit from AppModule/main.ts. It contains no HTTP controllers —
 * only the BullMQ worker that consumes contract-analysis jobs. Run it as its own process
 * (`pnpm start:worker`) so analysis load (CPU-heavy OCR, network-bound AI calls) can be scaled
 * independently from the API's request-handling capacity, and so a slow/stuck analysis job can
 * never block an HTTP request.
 *
 * Deliberately does NOT import ScheduleModule/NotificationsModule's cron job — only the API
 * process runs scheduled jobs, so a job can never fire twice across both processes. It does get
 * NotificationsService directly (just the Prisma-backed service, not the cron job) so the
 * processor can notify on completion.
 */
@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    QueueModule,
    BullModule.registerQueue({ name: CONTRACT_ANALYSIS_QUEUE }),
    AiModule,
    OcrModule,
  ],
  providers: [ContractsProcessor, DocumentExtractionService, NotificationsService],
})
export class WorkerModule {}
