import { Injectable, NotFoundException, InternalServerErrorException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { buildNegotiationPrompt } from './negotiation.prompts';

function parseJsonResponse(raw: string) {
  const cleaned = raw.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
  return JSON.parse(cleaned);
}

@Injectable()
export class NegotiationService {
  private readonly logger = new Logger(NegotiationService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  async listForContract(contractId: string) {
    return this.prisma.negotiationPoint.findMany({
      where: { contractId },
      orderBy: { priority: 'asc' },
    });
  }

  /** Builds a full negotiation playbook covering every HIGH/CRITICAL clause. */
  async generatePlaybook(orgId: string, contractId: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: { aiReports: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }

    const report = contract.aiReports[0];
    if (!report) throw new NotFoundException('No AI report found for this contract yet');

    // Clear old playbook for this contract before regenerating
    await this.prisma.negotiationPoint.deleteMany({ where: { contractId } });

    const clauses = (report.clauses as any[]).filter(
      (c) => c.riskLevel === 'HIGH' || c.riskLevel === 'CRITICAL',
    );

    const points = [];
    for (const clause of clauses) {
      const prompt = buildNegotiationPrompt({
        clauseType: clause.type,
        excerpt: clause.excerpt,
        riskLevel: clause.riskLevel,
        explanation: clause.explanation,
      });

      let response;
      try {
        response = await this.client.responses.create({ model: this.model, input: prompt, temperature: 0.2 });
      } catch (err) {
        this.logger.error('Negotiation generation call failed', err as Error);
        throw new InternalServerErrorException('AI negotiation provider error');
      }

      let parsed: any;
      try {
        parsed = parseJsonResponse(response.output_text ?? '');
      } catch (err) {
        this.logger.error('Failed to parse negotiation response', err as Error);
        throw new InternalServerErrorException('AI negotiation response could not be parsed');
      }

      const point = await this.prisma.negotiationPoint.create({
        data: {
          contractId,
          clauseType: clause.type,
          ourPosition: parsed.ourPosition,
          counterAsk: parsed.counterAsk,
          fallback: parsed.fallback,
          priority: parsed.priority ?? 3,
        },
      });
      points.push(point);
    }

    return points.sort((a, b) => a.priority - b.priority);
  }
}
