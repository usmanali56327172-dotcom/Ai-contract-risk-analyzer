import { Controller, Get, Post, Param, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { NegotiationService } from './negotiation.service';

@Controller('contracts/:contractId/negotiation')
@UseGuards(JwtAuthGuard)
export class NegotiationController {
  constructor(private readonly negotiationService: NegotiationService) {}

  @Get()
  list(@Param('contractId') contractId: string) {
    return this.negotiationService.listForContract(contractId);
  }

  @Post('generate')
  generate(@Req() req: any, @Param('contractId') contractId: string) {
    return this.negotiationService.generatePlaybook(req.user.orgId, contractId);
  }
}
