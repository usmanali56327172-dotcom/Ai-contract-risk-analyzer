export function buildNegotiationPrompt(params: {
  clauseType: string;
  excerpt: string;
  riskLevel: string;
  explanation: string;
}): string {
  const { clauseType, excerpt, riskLevel, explanation } = params;
  return `You are an experienced commercial negotiator advising the party reviewing this contract
(not the drafting party). A ${clauseType} clause was flagged as ${riskLevel} risk: "${explanation}"

Clause excerpt:
"""
${excerpt}
"""

Produce a negotiation strategy for this specific clause. Return ONLY valid JSON (no markdown
fences, no preamble) matching exactly:

{
  "ourPosition": string (what we should push for and why, 2-3 sentences),
  "counterAsk": string (the specific counter-proposal language or terms to request),
  "fallback": string (an acceptable compromise position if the counter-ask is rejected),
  "priority": number (1-5, where 1 = must-win issue, 5 = nice-to-have)
}`;
}
