import { Controller, Get, Post, Body, Req, Headers, UseGuards, BadRequestException } from '@nestjs/common';
import type { RawBodyRequest } from '@nestjs/common';
import type { Request } from 'express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { BillingService } from './billing.service';
import { CreateCheckoutSessionDto } from './dto/billing.dto';

@Controller('billing')
export class BillingController {
  constructor(private readonly billingService: BillingService) {}

  @UseGuards(JwtAuthGuard)
  @Get('subscription')
  getSubscription(@Req() req: any) {
    return this.billingService.getSubscription(req.user.orgId);
  }

  @UseGuards(JwtAuthGuard)
  @Post('checkout-session')
  createCheckoutSession(@Req() req: any, @Body() dto: CreateCheckoutSessionDto) {
    return this.billingService.createCheckoutSession(req.user.orgId, dto.priceId);
  }

  @UseGuards(JwtAuthGuard)
  @Post('portal-session')
  createPortalSession(@Req() req: any) {
    return this.billingService.createPortalSession(req.user.orgId);
  }

  // No JwtAuthGuard — Stripe calls this directly, authenticated by signature instead of a JWT.
  // Requires `rawBody: true` in NestFactory.create (see main.ts) so req.rawBody is populated.
  @Post('webhook')
  async webhook(@Req() req: RawBodyRequest<Request>, @Headers('stripe-signature') signature: string) {
    if (!req.rawBody) {
      throw new BadRequestException('Raw body not available — check rawBody is enabled in main.ts');
    }
    await this.billingService.handleWebhook(req.rawBody, signature);
    return { received: true };
  }
}
