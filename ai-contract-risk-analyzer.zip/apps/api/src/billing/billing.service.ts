import { Injectable, Logger, NotFoundException, InternalServerErrorException, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';

// Maps a Stripe Price ID to our internal plan name. Extend this as you add prices in the
// Stripe dashboard — it's the one place that needs updating.
const PRICE_TO_PLAN: Record<string, string> = {};

@Injectable()
export class BillingService {
  private readonly logger = new Logger(BillingService.name);
  private readonly stripe: Stripe;
  private readonly frontendUrl: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly notifications: NotificationsService,
  ) {
    this.stripe = new Stripe(this.config.get<string>('STRIPE_SECRET_KEY', ''), {
      apiVersion: '2024-06-20',
    });
    this.frontendUrl = this.config.get<string>('FRONTEND_URL', 'http://localhost:3000');
  }

  async getSubscription(orgId: string) {
    const sub = await this.prisma.subscription.findUnique({ where: { organizationId: orgId } });
    return (
      sub ?? {
        organizationId: orgId,
        plan: 'free',
        status: 'active',
        currentPeriodEnd: null,
        stripeCustomerId: null,
      }
    );
  }

  private async getOrCreateStripeCustomer(orgId: string): Promise<string> {
    const existing = await this.prisma.subscription.findUnique({ where: { organizationId: orgId } });
    if (existing?.stripeCustomerId) return existing.stripeCustomerId;

    const org = await this.prisma.organization.findUnique({
      where: { id: orgId },
      include: { users: { include: { user: true }, where: { role: 'OWNER' }, take: 1 } },
    });
    if (!org) throw new NotFoundException('Organization not found');

    const ownerEmail = org.users[0]?.user.email;

    let customer: Stripe.Customer;
    try {
      customer = await this.stripe.customers.create({
        name: org.name,
        email: ownerEmail,
        metadata: { organizationId: orgId },
      });
    } catch (err) {
      this.logger.error('Stripe customer creation failed', err as Error);
      throw new InternalServerErrorException('Billing provider error');
    }

    await this.prisma.subscription.upsert({
      where: { organizationId: orgId },
      create: { organizationId: orgId, stripeCustomerId: customer.id },
      update: { stripeCustomerId: customer.id },
    });

    return customer.id;
  }

  async createCheckoutSession(orgId: string, priceId: string): Promise<{ url: string }> {
    const customerId = await this.getOrCreateStripeCustomer(orgId);

    let session: Stripe.Checkout.Session;
    try {
      session = await this.stripe.checkout.sessions.create({
        customer: customerId,
        mode: 'subscription',
        line_items: [{ price: priceId, quantity: 1 }],
        success_url: `${this.frontendUrl}/billing?checkout=success`,
        cancel_url: `${this.frontendUrl}/billing?checkout=cancelled`,
        metadata: { organizationId: orgId },
      });
    } catch (err) {
      this.logger.error('Stripe checkout session creation failed', err as Error);
      throw new InternalServerErrorException('Billing provider error');
    }

    if (!session.url) throw new InternalServerErrorException('Stripe did not return a checkout URL');
    return { url: session.url };
  }

  async createPortalSession(orgId: string): Promise<{ url: string }> {
    const customerId = await this.getOrCreateStripeCustomer(orgId);

    let session: Stripe.BillingPortal.Session;
    try {
      session = await this.stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: `${this.frontendUrl}/billing`,
      });
    } catch (err) {
      this.logger.error('Stripe portal session creation failed', err as Error);
      throw new InternalServerErrorException('Billing provider error');
    }

    return { url: session.url };
  }

  /** Verifies the Stripe signature and dispatches the event. Throws if the signature is invalid. */
  async handleWebhook(rawBody: Buffer, signature: string): Promise<void> {
    const webhookSecret = this.config.get<string>('STRIPE_WEBHOOK_SECRET', '');

    let event: Stripe.Event;
    try {
      event = this.stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
    } catch (err) {
      this.logger.warn(`Stripe webhook signature verification failed: ${(err as Error).message}`);
      throw new BadRequestException('Invalid webhook signature');
    }

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const orgId = session.metadata?.organizationId;
        if (!orgId || !session.subscription) break;

        const subscription = await this.stripe.subscriptions.retrieve(session.subscription as string);
        await this.syncSubscriptionFromStripe(orgId, subscription);
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        const orgId = subscription.metadata?.organizationId
          ?? (await this.findOrgIdByCustomerId(subscription.customer as string));
        if (!orgId) break;
        await this.syncSubscriptionFromStripe(orgId, subscription);
        break;
      }
      default:
        // Unhandled event types are fine to ignore — Stripe sends many we don't act on.
        break;
    }
  }

  private async findOrgIdByCustomerId(stripeCustomerId: string): Promise<string | null> {
    const sub = await this.prisma.subscription.findUnique({ where: { stripeCustomerId } });
    return sub?.organizationId ?? null;
  }

  private async syncSubscriptionFromStripe(orgId: string, subscription: Stripe.Subscription): Promise<void> {
    const priceId = subscription.items.data[0]?.price?.id;
    const plan = (priceId && PRICE_TO_PLAN[priceId]) || 'pro';

    await this.prisma.subscription.upsert({
      where: { organizationId: orgId },
      create: {
        organizationId: orgId,
        stripeCustomerId: subscription.customer as string,
        stripeSubscriptionId: subscription.id,
        plan,
        status: subscription.status,
        currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      },
      update: {
        stripeSubscriptionId: subscription.id,
        plan: subscription.status === 'canceled' ? 'free' : plan,
        status: subscription.status,
        currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      },
    });

    await this.notifications.create({
      organizationId: orgId,
      type: 'BILLING_UPDATED',
      title: subscription.status === 'canceled' ? 'Subscription cancelled' : 'Subscription updated',
      message: `Your plan is now "${plan}" (${subscription.status}).`,
    });
  }
}
