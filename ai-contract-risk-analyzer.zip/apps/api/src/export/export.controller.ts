import { Controller, Get, Param, Req, Res, UseGuards } from '@nestjs/common';
import type { Response } from 'express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ExportService } from './export.service';

@Controller('contracts/:contractId/export')
@UseGuards(JwtAuthGuard)
export class ExportController {
  constructor(private readonly exportService: ExportService) {}

  @Get('pdf')
  async exportPdf(@Req() req: any, @Param('contractId') contractId: string, @Res() res: Response) {
    const buffer = await this.exportService.generatePdf(req.user.orgId, contractId);
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="contract-report-${contractId}.pdf"`,
    });
    res.send(buffer);
  }

  @Get('docx')
  async exportDocx(@Req() req: any, @Param('contractId') contractId: string, @Res() res: Response) {
    const buffer = await this.exportService.generateDocx(req.user.orgId, contractId);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': `attachment; filename="contract-report-${contractId}.docx"`,
    });
    res.send(buffer);
  }
}
