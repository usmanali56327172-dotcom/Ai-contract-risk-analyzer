import { Injectable, NotFoundException } from '@nestjs/common';
import PDFDocument from 'pdfkit';
import {
  Document,
  Packer,
  Paragraph,
  HeadingLevel,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
} from 'docx';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ExportService {
  constructor(private readonly prisma: PrismaService) {}

  private async loadReportData(orgId: string, contractId: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: {
        aiReports: { orderBy: { createdAt: 'desc' }, take: 1 },
        riskScores: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }
    const report = contract.aiReports[0];
    const risk = contract.riskScores[0];
    if (!report || !risk) {
      throw new NotFoundException('This contract has no completed AI report to export yet');
    }
    return { contract, report, risk };
  }

  async generatePdf(orgId: string, contractId: string): Promise<Buffer> {
    const { contract, report, risk } = await this.loadReportData(orgId, contractId);
    const clauses = report.clauses as any[];
    const missingClauses = report.missingClauses as any[];
    const recommendations = report.recommendations as string[];

    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ margin: 50 });
      const chunks: Buffer[] = [];
      doc.on('data', (chunk: Buffer) => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(20).text(contract.title, { underline: false });
      doc.moveDown(0.3);
      doc.fontSize(10).fillColor('#666666').text(`AI Contract Risk Report — generated ${new Date().toLocaleDateString()}`);
      doc.moveDown(1);

      doc.fillColor('#000000').fontSize(14).text('Risk Scores', { underline: true });
      doc.moveDown(0.3);
      doc.fontSize(11);
      doc.text(`Overall: ${risk.overallScore}/100 (${risk.level})`);
      doc.text(`Legal: ${risk.legalRisk}/100`);
      doc.text(`Financial: ${risk.financialRisk}/100`);
      doc.text(`Operational: ${risk.operationalRisk}/100`);
      doc.text(`Compliance: ${risk.complianceRisk}/100`);
      doc.moveDown(1);

      doc.fontSize(14).text('Executive Summary', { underline: true });
      doc.moveDown(0.3);
      doc.fontSize(11).text(report.executiveSummary, { align: 'justify' });
      doc.moveDown(1);

      doc.fontSize(14).text('Detected Clauses', { underline: true });
      doc.moveDown(0.3);
      for (const clause of clauses) {
        doc.fontSize(12).fillColor('#1a1a1a').text(`${clause.type} — ${clause.riskLevel}`, { continued: false });
        doc.fontSize(10).fillColor('#444444').text(`"${clause.excerpt}"`, { italics: true } as any);
        doc.fontSize(10).fillColor('#000000').text(clause.explanation);
        doc.moveDown(0.5);
      }

      if (missingClauses?.length) {
        doc.moveDown(0.5);
        doc.fontSize(14).fillColor('#000000').text('Missing Clauses', { underline: true });
        doc.moveDown(0.3);
        for (const m of missingClauses) {
          doc.fontSize(11).text(`• ${m.type}: ${m.reason}`);
        }
      }

      if (recommendations?.length) {
        doc.moveDown(1);
        doc.fontSize(14).text('Recommendations', { underline: true });
        doc.moveDown(0.3);
        for (const r of recommendations) {
          doc.fontSize(11).text(`• ${r}`);
        }
      }

      doc.moveDown(1.5);
      doc.fontSize(8).fillColor('#888888').text(
        `Model: ${report.model} · Prompt v${report.promptVersion} · Confidence: ${Math.round(report.confidenceScore * 100)}%`,
      );

      doc.end();
    });
  }

  async generateDocx(orgId: string, contractId: string): Promise<Buffer> {
    const { contract, report, risk } = await this.loadReportData(orgId, contractId);
    const clauses = report.clauses as any[];
    const missingClauses = report.missingClauses as any[];
    const recommendations = report.recommendations as string[];

    const riskTable = new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      rows: [
        new TableRow({
          children: ['Dimension', 'Score'].map(
            (t) => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: t, bold: true })] })] }),
          ),
        }),
        ...[
          ['Overall', `${risk.overallScore}/100 (${risk.level})`],
          ['Legal', `${risk.legalRisk}/100`],
          ['Financial', `${risk.financialRisk}/100`],
          ['Operational', `${risk.operationalRisk}/100`],
          ['Compliance', `${risk.complianceRisk}/100`],
        ].map(
          ([label, value]) =>
            new TableRow({
              children: [label, value].map((t) => new TableCell({ children: [new Paragraph(t)] })),
            }),
        ),
      ],
    });

    const clauseParagraphs = clauses.flatMap((c: any) => [
      new Paragraph({ text: `${c.type} — ${c.riskLevel}`, heading: HeadingLevel.HEADING_3 }),
      new Paragraph({ children: [new TextRun({ text: `"${c.excerpt}"`, italics: true })] }),
      new Paragraph({ text: c.explanation }),
    ]);

    const missingParagraphs = (missingClauses ?? []).map(
      (m: any) => new Paragraph({ text: `${m.type}: ${m.reason}`, bullet: { level: 0 } }),
    );

    const recommendationParagraphs = (recommendations ?? []).map(
      (r: string) => new Paragraph({ text: r, bullet: { level: 0 } }),
    );

    const doc = new Document({
      sections: [
        {
          children: [
            new Paragraph({ text: contract.title, heading: HeadingLevel.TITLE }),
            new Paragraph({ text: `AI Contract Risk Report — generated ${new Date().toLocaleDateString()}` }),
            new Paragraph({ text: '' }),
            new Paragraph({ text: 'Risk Scores', heading: HeadingLevel.HEADING_1 }),
            riskTable,
            new Paragraph({ text: '' }),
            new Paragraph({ text: 'Executive Summary', heading: HeadingLevel.HEADING_1 }),
            new Paragraph({ text: report.executiveSummary }),
            new Paragraph({ text: '' }),
            new Paragraph({ text: 'Detected Clauses', heading: HeadingLevel.HEADING_1 }),
            ...clauseParagraphs,
            new Paragraph({ text: 'Missing Clauses', heading: HeadingLevel.HEADING_1 }),
            ...(missingParagraphs.length ? missingParagraphs : [new Paragraph({ text: 'None detected.' })]),
            new Paragraph({ text: 'Recommendations', heading: HeadingLevel.HEADING_1 }),
            ...recommendationParagraphs,
          ],
        },
      ],
    });

    return Packer.toBuffer(doc);
  }
}
