import { Module } from '@nestjs/common';
import { MulterModule } from '@nestjs/platform-express';
import { BullModule } from '@nestjs/bullmq';
import { ContractsController } from './contracts.controller';
import { ContractsService } from './contracts.service';
import { AuthModule } from '../auth/auth.module';
import { CONTRACT_ANALYSIS_QUEUE } from '../queue/queue.module';

// NOTE: ContractsProcessor (the BullMQ worker that actually does extraction + AI analysis) is
// deliberately NOT provided here. It runs in a separate process — see worker.module.ts and
// worker.ts — so the HTTP API and the CPU/IO-heavy analysis work can be deployed and scaled
// independently. This module only needs to be able to enqueue jobs, not process them.
@Module({
  imports: [
    MulterModule.register({ storage: undefined }), // memory storage (default) for buffer access
    BullModule.registerQueue({ name: CONTRACT_ANALYSIS_QUEUE }),
    AuthModule,
  ],
  controllers: [ContractsController],
  providers: [ContractsService],
})
export class ContractsModule {}
