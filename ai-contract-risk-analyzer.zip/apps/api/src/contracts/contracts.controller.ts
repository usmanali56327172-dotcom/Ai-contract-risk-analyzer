import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseGuards,
  UseInterceptors,
  UploadedFile,
  Req,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ContractsService } from './contracts.service';

const ALLOWED_MIME_TYPES = new Set([
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);
const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024;

@Controller('contracts')
@UseGuards(JwtAuthGuard)
export class ContractsController {
  constructor(private readonly contractsService: ContractsService) {}

  @Get()
  list(@Req() req: any) {
    return this.contractsService.listForOrg(req.user.orgId);
  }

  @Get(':id')
  getOne(@Req() req: any, @Param('id') id: string) {
    return this.contractsService.getById(req.user.orgId, id);
  }

  @Post('upload')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_FILE_SIZE_BYTES } }))
  async upload(@Req() req: any, @UploadedFile() file: Express.Multer.File, @Body('title') title: string) {
    if (!file) throw new BadRequestException('No file uploaded');
    if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
      throw new BadRequestException('Only PDF and DOCX files are supported');
    }

    return this.contractsService.uploadAndEnqueue({
      orgId: req.user.orgId,
      userId: req.user.sub,
      title: title || file.originalname,
      fileName: file.originalname,
      mimeType: file.mimetype,
      buffer: file.buffer,
    });
  }
}
