import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import * as fs from 'fs/promises';
import * as path from 'path';
import { PrismaService } from '../prisma/prisma.service';
import { CONTRACT_ANALYSIS_QUEUE } from '../queue/queue.module';

const STORAGE_ROOT = process.env.STORAGE_ROOT || path.join(process.cwd(), 'storage', 'contracts');

export interface AnalyzeContractJobData {
  contractId: string;
  versionId: string;
  orgId: string;
  userId: string;
}

@Injectable()
export class ContractsService {
  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue(CONTRACT_ANALYSIS_QUEUE) private readonly analysisQueue: Queue<AnalyzeContractJobData>,
  ) {}

  async listForOrg(orgId: string) {
    return this.prisma.contract.findMany({
      where: { organizationId: orgId },
      orderBy: { createdAt: 'desc' },
      include: { riskScores: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });
  }

  async getById(orgId: string, contractId: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: {
        versions: { orderBy: { versionNum: 'desc' } },
        aiReports: { orderBy: { createdAt: 'desc' } },
        riskScores: { orderBy: { createdAt: 'desc' } },
      },
    });
    if (!contract) throw new NotFoundException('Contract not found');
    if (contract.organizationId !== orgId) throw new ForbiddenException('Not your organization');
    return contract;
  }

  /**
   * Saves the uploaded file and creates the contract/version rows, then hands off the actual
   * text extraction + AI analysis to a BullMQ worker (see ContractsProcessor). This means the
   * upload request returns immediately with status PROCESSING instead of blocking on the AI call
   * — important once files get large or uploads happen concurrently.
   */
  async uploadAndEnqueue(params: {
    orgId: string;
    userId: string;
    title: string;
    fileName: string;
    mimeType: string;
    buffer: Buffer;
  }) {
    const { orgId, userId, title, fileName, mimeType, buffer } = params;

    const contract = await this.prisma.contract.create({
      data: {
        title,
        organizationId: orgId,
        uploadedById: userId,
        status: 'PROCESSING',
      },
    });

    await fs.mkdir(path.join(STORAGE_ROOT, contract.id), { recursive: true });
    const storagePath = path.join(STORAGE_ROOT, contract.id, fileName);
    await fs.writeFile(storagePath, buffer);

    const version = await this.prisma.contractVersion.create({
      data: {
        contractId: contract.id,
        versionNum: 1,
        fileName,
        fileType: mimeType,
        storagePath,
      },
    });

    await this.analysisQueue.add(
      'analyze',
      { contractId: contract.id, versionId: version.id, orgId, userId },
      { jobId: `analyze-${version.id}` },
    );

    return this.getById(orgId, contract.id);
  }
}

