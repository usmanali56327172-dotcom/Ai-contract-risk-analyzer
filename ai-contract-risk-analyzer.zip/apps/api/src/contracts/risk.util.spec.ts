import { levelFromScore } from './risk.util';

describe('levelFromScore', () => {
  it('classifies scores below 30 as LOW', () => {
    expect(levelFromScore(0)).toBe('LOW');
    expect(levelFromScore(29)).toBe('LOW');
  });

  it('classifies 30-54 as MEDIUM', () => {
    expect(levelFromScore(30)).toBe('MEDIUM');
    expect(levelFromScore(54)).toBe('MEDIUM');
  });

  it('classifies 55-79 as HIGH', () => {
    expect(levelFromScore(55)).toBe('HIGH');
    expect(levelFromScore(79)).toBe('HIGH');
  });

  it('classifies 80 and above as CRITICAL', () => {
    expect(levelFromScore(80)).toBe('CRITICAL');
    expect(levelFromScore(100)).toBe('CRITICAL');
  });
});
