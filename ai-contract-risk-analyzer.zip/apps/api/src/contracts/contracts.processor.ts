import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import * as fs from 'fs/promises';
import { PrismaService } from '../prisma/prisma.service';
import { DocumentExtractionService } from './document-extraction.service';
import { AiAnalysisService } from '../ai/ai-analysis.service';
import { levelFromScore } from './risk.util';
import { CONTRACT_ANALYSIS_QUEUE } from '../queue/queue.module';
import { AnalyzeContractJobData } from './contracts.service';
import { NotificationsService } from '../notifications/notifications.service';

@Processor(CONTRACT_ANALYSIS_QUEUE)
export class ContractsProcessor extends WorkerHost {
  private readonly logger = new Logger(ContractsProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly extraction: DocumentExtractionService,
    private readonly ai: AiAnalysisService,
    private readonly notifications: NotificationsService,
  ) {
    super();
  }

  async process(job: Job<AnalyzeContractJobData>): Promise<void> {
    const { contractId, versionId, orgId, userId } = job.data;
    this.logger.log(`Processing analysis job for contract ${contractId} (attempt ${job.attemptsMade + 1})`);

    try {
      const version = await this.prisma.contractVersion.findUniqueOrThrow({ where: { id: versionId } });

      const buffer = await fs.readFile(version.storagePath);
      const extraction = await this.extraction.extractText(buffer, version.fileType);

      await this.prisma.contractVersion.update({
        where: { id: versionId },
        data: {
          extractedText: extraction.text,
          ocrUsed: extraction.ocrUsed,
          ocrConfidence: extraction.ocrConfidence ?? null,
        },
      });

      const analysis = await this.ai.analyzeContract(extraction.text);

      await this.prisma.$transaction([
        this.prisma.contractVersion.update({
          where: { id: versionId },
          data: { detectedLanguage: analysis.detectedLanguage },
        }),
        this.prisma.aIReport.create({
          data: {
            contractId,
            executiveSummary: analysis.executiveSummary,
            clauses: analysis.clauses as any,
            missingClauses: analysis.missingClauses as any,
            recommendations: analysis.recommendations as any,
            confidenceScore: analysis.confidenceScore,
            model: analysis.model,
            promptVersion: analysis.promptVersion,
          },
        }),
        this.prisma.riskScore.create({
          data: {
            contractId,
            overallScore: analysis.overallRiskScore,
            legalRisk: analysis.risks.legalRisk,
            financialRisk: analysis.risks.financialRisk,
            operationalRisk: analysis.risks.operationalRisk,
            complianceRisk: analysis.risks.complianceRisk,
            level: levelFromScore(analysis.overallRiskScore),
          },
        }),
        this.prisma.contract.update({
          where: { id: contractId },
          data: { status: 'ANALYZED' },
        }),
        this.prisma.activityLog.create({
          data: {
            organizationId: orgId,
            userId,
            action: 'CONTRACT_ANALYZED',
            metadata: { contractId },
          },
        }),
      ]);

      this.logger.log(`Contract ${contractId} analyzed successfully`);

      const contract = await this.prisma.contract.findUnique({ where: { id: contractId } });
      await this.notifications.create({
        organizationId: orgId,
        userId,
        type: 'CONTRACT_ANALYZED',
        title: `"${contract?.title}" analysis complete`,
        message: `Risk level: ${levelFromScore(analysis.overallRiskScore)} (${analysis.overallRiskScore}/100). ${analysis.clauses.length} clause(s) detected, ${analysis.missingClauses.length} missing.`,
        metadata: { contractId },
      });
    } catch (err) {
      this.logger.error(`Analysis failed for contract ${contractId}`, err as Error);
      // Only mark FAILED once retries are exhausted; BullMQ will re-run this job otherwise.
      if (job.attemptsMade + 1 >= (job.opts.attempts ?? 1)) {
        await this.prisma.contract.update({ where: { id: contractId }, data: { status: 'FAILED' } });
      }
      throw err; // rethrow so BullMQ marks the job failed / retries it
    }
  }
}
