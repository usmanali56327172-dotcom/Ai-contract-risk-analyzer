import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const pdfParse = require('pdf-parse');
import * as mammoth from 'mammoth';
import { OcrService } from '../ocr/ocr.service';

export interface ExtractionResult {
  text: string;
  ocrUsed: boolean;
  ocrConfidence?: number;
}

// Below this many characters of extracted text, a "text layer" is almost certainly just page
// numbers, headers, or noise from a scanned image — treat it as scanned and fall back to OCR.
const MIN_MEANINGFUL_TEXT_LENGTH = 40;

@Injectable()
export class DocumentExtractionService {
  private readonly logger = new Logger(DocumentExtractionService.name);

  constructor(
    private readonly ocr: OcrService,
    private readonly config: ConfigService,
  ) {}

  async extractText(buffer: Buffer, mimeType: string): Promise<ExtractionResult> {
    if (mimeType === 'application/pdf') {
      const result = await pdfParse(buffer);
      const text = (result.text ?? '').trim();

      if (text.length >= MIN_MEANINGFUL_TEXT_LENGTH) {
        return { text, ocrUsed: false };
      }

      // No usable text layer — this is a scanned/image-only PDF. Fall back to OCR rather than
      // rejecting the upload.
      this.logger.log('PDF has no meaningful text layer; falling back to OCR');
      const language = this.config.get<string>('OCR_LANGUAGE', 'eng');
      const ocrResult = await this.ocr.extractTextFromScannedPdf(buffer, language);

      if (!ocrResult.text.trim()) {
        throw new BadRequestException(
          'OCR ran but recovered no readable text from this PDF. The scan quality may be too low.',
        );
      }

      return { text: ocrResult.text, ocrUsed: true, ocrConfidence: ocrResult.confidence };
    }

    if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      const result = await mammoth.extractRawText({ buffer });
      return { text: result.value.trim(), ocrUsed: false };
    }

    throw new BadRequestException(`Unsupported file type: ${mimeType}`);
  }
}
