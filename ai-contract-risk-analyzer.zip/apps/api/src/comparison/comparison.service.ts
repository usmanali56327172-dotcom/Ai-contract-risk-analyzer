import { Injectable, NotFoundException, BadRequestException, InternalServerErrorException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { buildComparisonPrompt } from './comparison.prompts';
import { NotificationsService } from '../notifications/notifications.service';

function parseJsonResponse(raw: string) {
  const cleaned = raw.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
  return JSON.parse(cleaned);
}

@Injectable()
export class ComparisonService {
  private readonly logger = new Logger(ComparisonService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly notifications: NotificationsService,
  ) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  async listForOrg(orgId: string) {
    return this.prisma.contractComparison.findMany({
      where: { organizationId: orgId },
      orderBy: { createdAt: 'desc' },
      include: {
        contractA: { select: { id: true, title: true } },
        contractB: { select: { id: true, title: true } },
      },
    });
  }

  async getById(orgId: string, id: string) {
    const comparison = await this.prisma.contractComparison.findUnique({
      where: { id },
      include: {
        contractA: { select: { id: true, title: true } },
        contractB: { select: { id: true, title: true } },
        diffs: true,
      },
    });
    if (!comparison || comparison.organizationId !== orgId) {
      throw new NotFoundException('Comparison not found');
    }
    return comparison;
  }

  async compare(orgId: string, contractAId: string, contractBId: string) {
    if (contractAId === contractBId) {
      throw new BadRequestException('Choose two different contracts to compare');
    }

    const [contractA, contractB] = await Promise.all([
      this.prisma.contract.findUnique({
        where: { id: contractAId },
        include: {
          aiReports: { orderBy: { createdAt: 'desc' }, take: 1 },
          riskScores: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
      }),
      this.prisma.contract.findUnique({
        where: { id: contractBId },
        include: {
          aiReports: { orderBy: { createdAt: 'desc' }, take: 1 },
          riskScores: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
      }),
    ]);

    if (!contractA || contractA.organizationId !== orgId) throw new NotFoundException('Contract A not found');
    if (!contractB || contractB.organizationId !== orgId) throw new NotFoundException('Contract B not found');

    const reportA = contractA.aiReports[0];
    const reportB = contractB.aiReports[0];
    if (!reportA || !reportB) {
      throw new BadRequestException('Both contracts must have completed AI analysis before comparing');
    }

    const prompt = buildComparisonPrompt({
      titleA: contractA.title,
      titleB: contractB.title,
      clausesA: reportA.clauses as any,
      clausesB: reportB.clauses as any,
    });

    let response;
    try {
      response = await this.client.responses.create({ model: this.model, input: prompt, temperature: 0 });
    } catch (err) {
      this.logger.error('Comparison call failed', err as Error);
      throw new InternalServerErrorException('AI comparison provider error');
    }

    let parsed: any;
    try {
      parsed = parseJsonResponse(response.output_text ?? '');
    } catch (err) {
      this.logger.error('Failed to parse comparison response', err as Error);
      throw new InternalServerErrorException('AI comparison response could not be parsed');
    }

    const clausesAByType = new Map((reportA.clauses as any[]).map((c: any) => [c.type, c]));
    const clausesBByType = new Map((reportB.clauses as any[]).map((c: any) => [c.type, c]));

    const scoreA = contractA.riskScores[0]?.overallScore ?? 0;
    const scoreB = contractB.riskScores[0]?.overallScore ?? 0;

    const comparison = await this.prisma.contractComparison.create({
      data: {
        organizationId: orgId,
        contractAId,
        contractBId,
        overallSummary: parsed.overallSummary,
        riskDelta: scoreB - scoreA,
        diffs: {
          create: (parsed.clauseDiffs as any[])
            .filter((d: any) => clausesAByType.has(d.clauseType) || clausesBByType.has(d.clauseType) || d.changeType)
            .map((d: any) => ({
              clauseType: d.clauseType,
              changeType: d.changeType,
              textA: clausesAByType.get(d.clauseType)?.excerpt ?? null,
              textB: clausesBByType.get(d.clauseType)?.excerpt ?? null,
              diffSummary: d.diffSummary,
            })),
        },
      },
      include: {
        contractA: { select: { id: true, title: true } },
        contractB: { select: { id: true, title: true } },
        diffs: true,
      },
    });

    await this.notifications.create({
      organizationId: orgId,
      type: 'COMPARISON_COMPLETED',
      title: `Comparison ready: "${comparison.contractA.title}" vs "${comparison.contractB.title}"`,
      message: comparison.overallSummary.slice(0, 200),
      metadata: { comparisonId: comparison.id },
    });

    return comparison;
  }
}
