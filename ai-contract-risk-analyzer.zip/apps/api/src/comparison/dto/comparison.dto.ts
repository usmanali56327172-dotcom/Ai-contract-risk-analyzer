import { IsString } from 'class-validator';

export class CompareContractsDto {
  @IsString()
  contractAId: string;

  @IsString()
  contractBId: string;
}
