interface ClauseForCompare {
  type: string;
  excerpt: string;
  riskLevel: string;
}

export function buildComparisonPrompt(params: {
  titleA: string;
  titleB: string;
  clausesA: ClauseForCompare[];
  clausesB: ClauseForCompare[];
}): string {
  const { titleA, titleB, clausesA, clausesB } = params;

  const byTypeA = new Map(clausesA.map((c) => [c.type, c]));
  const byTypeB = new Map(clausesB.map((c) => [c.type, c]));
  const allTypes = Array.from(new Set([...byTypeA.keys(), ...byTypeB.keys()]));

  const pairs = allTypes.map((type) => {
    const a = byTypeA.get(type);
    const b = byTypeB.get(type);
    return `Clause type: ${type}
Contract A ("${titleA}"): ${a ? `[${a.riskLevel} risk] "${a.excerpt}"` : 'NOT PRESENT'}
Contract B ("${titleB}"): ${b ? `[${b.riskLevel} risk] "${b.excerpt}"` : 'NOT PRESENT'}`;
  });

  return `You are comparing two contracts clause by clause: "${titleA}" (A) versus "${titleB}" (B).
For each clause type below, determine how it changed from A to B. Return ONLY valid JSON (no
markdown fences, no preamble) matching exactly:

{
  "clauseDiffs": [
    {
      "clauseType": string (must match one of the clause types given below exactly),
      "changeType": "ADDED" | "REMOVED" | "MODIFIED" | "UNCHANGED",
      "diffSummary": string (1-2 sentences on what specifically changed and whether it's better or worse for the party reviewing; if UNCHANGED, briefly say so)
    }
  ],
  "overallSummary": string (3-5 sentences: which contract is more favorable overall and why, referencing the most consequential differences found)
}

"ADDED" = present in B but not A. "REMOVED" = present in A but not B. "MODIFIED" = present in
both but the substance differs. "UNCHANGED" = present in both with no meaningful difference.

CLAUSE PAIRS TO COMPARE:
${pairs.join('\n\n')}`;
}
