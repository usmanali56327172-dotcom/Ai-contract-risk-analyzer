import { buildComparisonPrompt } from './comparison.prompts';

describe('buildComparisonPrompt', () => {
  it('marks a clause present only in B as needing an ADDED/REMOVED determination', () => {
    const prompt = buildComparisonPrompt({
      titleA: 'MSA v1',
      titleB: 'MSA v2',
      clausesA: [{ type: 'Payment', excerpt: 'Net 30', riskLevel: 'LOW' }],
      clausesB: [
        { type: 'Payment', excerpt: 'Net 45', riskLevel: 'LOW' },
        { type: 'Warranty', excerpt: 'No warranty given', riskLevel: 'HIGH' },
      ],
    });

    expect(prompt).toContain('Payment');
    expect(prompt).toContain('Net 30');
    expect(prompt).toContain('Net 45');
    expect(prompt).toContain('Warranty');
    expect(prompt).toContain('NOT PRESENT'); // Warranty absent from A
  });

  it('requests changeType classification for every clause type found in either contract', () => {
    const prompt = buildComparisonPrompt({
      titleA: 'A',
      titleB: 'B',
      clausesA: [{ type: 'Termination', excerpt: 'x', riskLevel: 'LOW' }],
      clausesB: [],
    });

    expect(prompt).toMatch(/ADDED.*REMOVED.*MODIFIED.*UNCHANGED/s);
    expect(prompt).toContain('Termination');
  });

  it('includes both contract titles so the model can reference them by name', () => {
    const prompt = buildComparisonPrompt({
      titleA: 'Vendor Agreement — Acme',
      titleB: 'Vendor Agreement — Beta Corp',
      clausesA: [],
      clausesB: [],
    });

    expect(prompt).toContain('Vendor Agreement — Acme');
    expect(prompt).toContain('Vendor Agreement — Beta Corp');
  });
});
