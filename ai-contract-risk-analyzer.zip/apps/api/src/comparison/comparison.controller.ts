import { Controller, Get, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ComparisonService } from './comparison.service';
import { CompareContractsDto } from './dto/comparison.dto';

@Controller('comparisons')
@UseGuards(JwtAuthGuard)
export class ComparisonController {
  constructor(private readonly comparisonService: ComparisonService) {}

  @Get()
  list(@Req() req: any) {
    return this.comparisonService.listForOrg(req.user.orgId);
  }

  @Post()
  compare(@Req() req: any, @Body() dto: CompareContractsDto) {
    return this.comparisonService.compare(req.user.orgId, dto.contractAId, dto.contractBId);
  }

  @Get(':id')
  getOne(@Req() req: any, @Param('id') id: string) {
    return this.comparisonService.getById(req.user.orgId, id);
  }
}
