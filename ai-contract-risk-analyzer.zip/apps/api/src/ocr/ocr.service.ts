import { Injectable, Logger, InternalServerErrorException } from '@nestjs/common';
import * as path from 'path';
import { pdfToPng } from 'pdf-to-png-converter';
import { createWorker } from 'tesseract.js';

export interface OcrResult {
  text: string;
  pageCount: number;
  confidence: number; // 0-100, averaged across pages
}

/**
 * Resolves the on-disk directory for a given language's Tesseract training data, installed as
 * a regular npm dependency (e.g. `@tesseract.js-data/eng`) rather than fetched from Tesseract's
 * default CDN at runtime. This is deliberate: it removes a runtime dependency on an external CDN
 * being reachable, and makes OCR fully reproducible from `pnpm install` alone.
 *
 * To support another language, `pnpm add @tesseract.js-data/<lang>` in apps/api and it will be
 * picked up automatically — no code change needed beyond passing that language code through.
 */
function resolveLangDataDir(lang: string): string {
  try {
    const pkgJsonPath = require.resolve(`@tesseract.js-data/${lang}/package.json`);
    return path.join(path.dirname(pkgJsonPath), '4.0.0_best_int');
  } catch {
    throw new InternalServerErrorException(
      `No local OCR language data installed for "${lang}". Run: pnpm add @tesseract.js-data/${lang} in apps/api.`,
    );
  }
}

@Injectable()
export class OcrService {
  private readonly logger = new Logger(OcrService.name);

  /** Rasterizes every page of a PDF buffer to a PNG buffer, then runs Tesseract OCR on each page. */
  async extractTextFromScannedPdf(buffer: Buffer, language = 'eng'): Promise<OcrResult> {
    const langPath = resolveLangDataDir(language);

    let pages;
    try {
      pages = await pdfToPng(buffer, { viewportScale: 2.0, disableFontFace: false });
    } catch (err) {
      this.logger.error('PDF rasterization failed', err as Error);
      throw new InternalServerErrorException('Could not rasterize PDF pages for OCR');
    }

    if (pages.length === 0) {
      throw new InternalServerErrorException('PDF has no pages to OCR');
    }

    const worker = await createWorker(language, 1, { langPath, cachePath: '/tmp/tesseract-cache' });

    const pageTexts: string[] = [];
    const confidences: number[] = [];

    try {
      for (const page of pages) {
        if (!page.content) continue; // metadata-only page output; nothing to OCR
        const { data } = await worker.recognize(page.content);
        pageTexts.push(data.text.trim());
        confidences.push(data.confidence);
      }
    } catch (err) {
      this.logger.error('OCR recognition failed', err as Error);
      throw new InternalServerErrorException('OCR text recognition failed');
    } finally {
      await worker.terminate();
    }

    if (confidences.length === 0) {
      throw new InternalServerErrorException('No renderable page content was produced for OCR');
    }

    return {
      text: pageTexts.join('\n\n--- Page Break ---\n\n'),
      pageCount: pages.length,
      confidence: confidences.reduce((a, b) => a + b, 0) / confidences.length,
    };
  }
}
