import { IsString, MinLength } from 'class-validator';

export class GenerateSingleRedlineDto {
  @IsString()
  clauseType: string;

  @IsString()
  @MinLength(10)
  originalText: string;

  @IsString()
  riskLevel: string;

  @IsString()
  explanation: string;
}
