import { Injectable, NotFoundException, InternalServerErrorException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { buildRedlinePrompt } from './redline.prompts';

function parseJsonResponse(raw: string) {
  const cleaned = raw.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
  return JSON.parse(cleaned);
}

@Injectable()
export class RedlineService {
  private readonly logger = new Logger(RedlineService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  async listForContract(contractId: string) {
    return this.prisma.redlineSuggestion.findMany({
      where: { contractId },
      orderBy: { createdAt: 'desc' },
    });
  }

  /** Generates redlines for every HIGH/CRITICAL clause in the latest AI report. */
  async generateForContract(orgId: string, contractId: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: { aiReports: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }

    const report = contract.aiReports[0];
    if (!report) throw new NotFoundException('No AI report found for this contract yet');

    const clauses = (report.clauses as any[]).filter(
      (c) => c.riskLevel === 'HIGH' || c.riskLevel === 'CRITICAL',
    );

    const results = [];
    for (const clause of clauses) {
      const suggestion = await this.generateSingle({
        contractId,
        clauseType: clause.type,
        originalText: clause.excerpt,
        riskLevel: clause.riskLevel,
        explanation: clause.explanation,
      });
      results.push(suggestion);
    }
    return results;
  }

  /** Ad hoc redline for a single clause of the caller's choosing. */
  async generateSingle(params: {
    contractId: string;
    clauseType: string;
    originalText: string;
    riskLevel: string;
    explanation: string;
  }) {
    const prompt = buildRedlinePrompt(params);

    let response;
    try {
      response = await this.client.responses.create({
        model: this.model,
        input: prompt,
        temperature: 0.2,
      });
    } catch (err) {
      this.logger.error('Redline generation call failed', err as Error);
      throw new InternalServerErrorException('AI redline provider error');
    }

    let parsed: any;
    try {
      parsed = parseJsonResponse(response.output_text ?? '');
    } catch (err) {
      this.logger.error('Failed to parse redline response', err as Error);
      throw new InternalServerErrorException('AI redline response could not be parsed');
    }

    return this.prisma.redlineSuggestion.create({
      data: {
        contractId: params.contractId,
        clauseType: params.clauseType,
        originalText: params.originalText,
        suggestedText: parsed.suggestedText,
        rationale: parsed.rationale,
        riskReduction: `${parsed.riskReductionFrom} -> ${parsed.riskReductionTo}`,
        model: this.model,
      },
    });
  }
}
