export function buildRedlinePrompt(params: {
  clauseType: string;
  originalText: string;
  riskLevel: string;
  explanation: string;
}): string {
  const { clauseType, originalText, riskLevel, explanation } = params;
  return `You are a senior contract negotiator drafting redlines. A ${clauseType} clause in a contract
was flagged as ${riskLevel} risk for this reason: "${explanation}"

Original clause text:
"""
${originalText}
"""

Rewrite this clause to materially reduce risk while remaining commercially reasonable and enforceable.
Return ONLY valid JSON (no markdown fences, no preamble) matching exactly:

{
  "suggestedText": string (the full rewritten clause, ready to drop into the contract),
  "rationale": string (2-4 sentences explaining specifically what changed and why it reduces risk),
  "riskReductionFrom": "LOW"|"MEDIUM"|"HIGH"|"CRITICAL",
  "riskReductionTo": "LOW"|"MEDIUM"|"HIGH"|"CRITICAL"
}`;
}
