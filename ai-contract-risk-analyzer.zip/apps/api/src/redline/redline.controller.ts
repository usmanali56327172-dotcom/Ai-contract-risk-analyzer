import { Controller, Get, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RedlineService } from './redline.service';
import { GenerateSingleRedlineDto } from './dto/redline.dto';

@Controller('contracts/:contractId/redlines')
@UseGuards(JwtAuthGuard)
export class RedlineController {
  constructor(private readonly redlineService: RedlineService) {}

  @Get()
  list(@Param('contractId') contractId: string) {
    return this.redlineService.listForContract(contractId);
  }

  @Post('generate')
  generateAll(@Req() req: any, @Param('contractId') contractId: string) {
    return this.redlineService.generateForContract(req.user.orgId, contractId);
  }

  @Post()
  generateSingle(@Param('contractId') contractId: string, @Body() dto: GenerateSingleRedlineDto) {
    return this.redlineService.generateSingle({ contractId, ...dto });
  }
}
