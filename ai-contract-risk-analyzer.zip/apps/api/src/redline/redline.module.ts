import { Module } from '@nestjs/common';
import { RedlineController } from './redline.controller';
import { RedlineService } from './redline.service';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [AuthModule],
  controllers: [RedlineController],
  providers: [RedlineService],
  exports: [RedlineService],
})
export class RedlineModule {}
