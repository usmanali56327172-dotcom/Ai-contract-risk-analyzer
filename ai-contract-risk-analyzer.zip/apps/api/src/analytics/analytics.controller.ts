import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { AnalyticsService } from './analytics.service';

@Controller('analytics')
@UseGuards(JwtAuthGuard)
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  @Get('risk-trends')
  riskTrends(@Req() req: any) {
    return this.analyticsService.riskTrends(req.user.orgId);
  }

  @Get('summary')
  summary(@Req() req: any) {
    return this.analyticsService.summary(req.user.orgId);
  }
}
