import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AnalyticsService {
  constructor(private readonly prisma: PrismaService) {}

  /** Monthly average risk score + level breakdown across all of the org's contracts. */
  async riskTrends(orgId: string) {
    const scores = await this.prisma.riskScore.findMany({
      where: { contract: { organizationId: orgId } },
      orderBy: { createdAt: 'asc' },
      select: {
        overallScore: true,
        legalRisk: true,
        financialRisk: true,
        operationalRisk: true,
        complianceRisk: true,
        level: true,
        createdAt: true,
        contractId: true,
      },
    });

    const byMonth = new Map<string, typeof scores>();
    for (const s of scores) {
      const key = `${s.createdAt.getFullYear()}-${String(s.createdAt.getMonth() + 1).padStart(2, '0')}`;
      if (!byMonth.has(key)) byMonth.set(key, []);
      byMonth.get(key)!.push(s);
    }

    const trend = Array.from(byMonth.entries())
      .sort(([a], [b]) => (a < b ? -1 : 1))
      .map(([month, items]) => ({
        month,
        contractCount: items.length,
        avgOverallScore: avg(items.map((i: any) => i.overallScore)),
        avgLegalRisk: avg(items.map((i: any) => i.legalRisk)),
        avgFinancialRisk: avg(items.map((i: any) => i.financialRisk)),
        avgOperationalRisk: avg(items.map((i: any) => i.operationalRisk)),
        avgComplianceRisk: avg(items.map((i: any) => i.complianceRisk)),
        highRiskCount: items.filter((i: any) => i.level === 'HIGH' || i.level === 'CRITICAL').length,
      }));

    return trend;
  }

  async summary(orgId: string) {
    const [totalContracts, riskScores, expiringSoon] = await Promise.all([
      this.prisma.contract.count({ where: { organizationId: orgId } }),
      this.prisma.riskScore.findMany({
        where: { contract: { organizationId: orgId } },
        orderBy: { createdAt: 'desc' },
        distinct: ['contractId'],
      }),
      this.prisma.contractDates.count({
        where: {
          contract: { organizationId: orgId },
          expiryDate: { lte: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), gte: new Date() },
        },
      }),
    ]);

    return {
      totalContracts,
      avgOverallRiskScore: avg(riskScores.map((r: any) => r.overallScore)),
      highRiskContracts: riskScores.filter((r: any) => r.level === 'HIGH' || r.level === 'CRITICAL').length,
      criticalRiskContracts: riskScores.filter((r: any) => r.level === 'CRITICAL').length,
      expiringWithin30Days: expiringSoon,
    };
  }
}

function avg(nums: number[]): number {
  if (nums.length === 0) return 0;
  return Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10;
}
