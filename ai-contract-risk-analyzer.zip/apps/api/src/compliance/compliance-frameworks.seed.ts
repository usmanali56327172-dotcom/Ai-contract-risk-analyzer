export const BUILT_IN_FRAMEWORKS: {
  code: string;
  name: string;
  description: string;
  rules: { code: string; description: string }[];
}[] = [
  {
    code: 'GDPR',
    name: 'General Data Protection Regulation',
    description: 'EU regulation governing processing of personal data.',
    rules: [
      { code: 'GDPR-ART-28', description: 'Contract must include a data processing agreement or Art. 28 processor obligations (scope, duration, nature and purpose of processing, sub-processor rules).' },
      { code: 'GDPR-ART-32', description: 'Contract must require appropriate technical and organizational security measures for personal data.' },
      { code: 'GDPR-ART-33', description: 'Contract must specify a data breach notification obligation and timeline.' },
      { code: 'GDPR-ART-44', description: 'If personal data may be transferred outside the EEA, the contract must specify an approved transfer mechanism (SCCs, adequacy decision, BCRs).' },
      { code: 'GDPR-DELETION', description: 'Contract must specify data deletion or return obligations at the end of the relationship.' },
    ],
  },
  {
    code: 'HIPAA',
    name: 'Health Insurance Portability and Accountability Act',
    description: 'US law governing protected health information (PHI).',
    rules: [
      { code: 'HIPAA-BAA', description: 'If the contract involves PHI, it must include or reference a Business Associate Agreement (BAA).' },
      { code: 'HIPAA-SAFEGUARDS', description: 'Contract must require administrative, physical, and technical safeguards for PHI.' },
      { code: 'HIPAA-BREACH', description: 'Contract must specify a breach notification process consistent with the HIPAA Breach Notification Rule.' },
      { code: 'HIPAA-MINIMUM-NECESSARY', description: 'Contract should limit use/disclosure of PHI to the minimum necessary for the stated purpose.' },
      { code: 'HIPAA-SUBCONTRACTOR', description: 'Contract must require subcontractors handling PHI to agree to equivalent restrictions.' },
    ],
  },
  {
    code: 'ISO27001',
    name: 'ISO/IEC 27001 Information Security Management',
    description: 'International standard for information security management systems.',
    rules: [
      { code: 'ISO-A5', description: 'Contract should reference information security policies applicable to the engagement.' },
      { code: 'ISO-A15', description: 'Contract must address supplier/third-party security requirements (A.15 supplier relationships).' },
      { code: 'ISO-A16', description: 'Contract must specify an information security incident management and reporting process.' },
      { code: 'ISO-A18', description: 'Contract must address compliance with legal, regulatory, and contractual security requirements.' },
      { code: 'ISO-AUDIT-RIGHT', description: 'Contract should grant a right to audit or request evidence of the counterparty\'s security controls.' },
    ],
  },
];
