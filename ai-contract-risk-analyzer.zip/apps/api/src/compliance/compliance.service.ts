import { Injectable, NotFoundException, InternalServerErrorException, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { BUILT_IN_FRAMEWORKS } from './compliance-frameworks.seed';
import { buildComplianceCheckPrompt } from './compliance.prompts';
import { CreateCustomFrameworkDto } from './dto/compliance.dto';
import { NotificationsService } from '../notifications/notifications.service';

function parseJsonResponse(raw: string) {
  const cleaned = raw.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
  return JSON.parse(cleaned);
}

@Injectable()
export class ComplianceService implements OnModuleInit {
  private readonly logger = new Logger(ComplianceService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly notifications: NotificationsService,
  ) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  /** Idempotently seeds the built-in GDPR/HIPAA/ISO 27001 frameworks on boot. */
  async onModuleInit() {
    for (const fw of BUILT_IN_FRAMEWORKS) {
      const existing = await this.prisma.complianceFramework.findUnique({ where: { code: fw.code } });
      if (existing) continue;

      await this.prisma.complianceFramework.create({
        data: {
          code: fw.code,
          name: fw.name,
          description: fw.description,
          isCustom: false,
          rules: { create: fw.rules },
        },
      });
    }
  }

  async listFrameworks(orgId: string) {
    return this.prisma.complianceFramework.findMany({
      where: { OR: [{ isCustom: false }, { organizationId: orgId }] },
      include: { rules: true },
      orderBy: { code: 'asc' },
    });
  }

  async createCustomFramework(orgId: string, dto: CreateCustomFrameworkDto) {
    return this.prisma.complianceFramework.create({
      data: {
        code: dto.code,
        name: dto.name,
        description: dto.description,
        isCustom: true,
        organizationId: orgId,
        rules: { create: dto.rules },
      },
      include: { rules: true },
    });
  }

  async getResultsForContract(contractId: string) {
    return this.prisma.complianceResult.findMany({
      where: { contractId },
      include: { rule: { include: { framework: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async runCheck(orgId: string, contractId: string, frameworkCode: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: { versions: { orderBy: { versionNum: 'desc' }, take: 1 } },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }

    const text = contract.versions[0]?.extractedText;
    if (!text) throw new NotFoundException('No extracted text found for this contract');

    const framework = await this.prisma.complianceFramework.findUnique({
      where: { code: frameworkCode },
      include: { rules: true },
    });
    if (!framework) throw new NotFoundException(`Unknown compliance framework: ${frameworkCode}`);
    if (framework.isCustom && framework.organizationId !== orgId) {
      throw new NotFoundException('Custom framework not found in your organization');
    }

    const prompt = buildComplianceCheckPrompt({
      frameworkName: framework.name,
      rules: framework.rules.map((r: any) => ({ code: r.code, description: r.description })),
      contractText: text,
    });

    let response;
    try {
      response = await this.client.responses.create({ model: this.model, input: prompt, temperature: 0 });
    } catch (err) {
      this.logger.error('Compliance check call failed', err as Error);
      throw new InternalServerErrorException('AI compliance-check provider error');
    }

    let parsed: any[];
    try {
      parsed = parseJsonResponse(response.output_text ?? '');
    } catch (err) {
      this.logger.error('Failed to parse compliance response', err as Error);
      throw new InternalServerErrorException('AI compliance response could not be parsed');
    }

    const ruleByCode = new Map<string, any>(framework.rules.map((r: any) => [r.code, r]));

    // Replace prior results for this framework on this contract
    await this.prisma.complianceResult.deleteMany({
      where: { contractId, rule: { frameworkId: framework.id } },
    });

    const created = [];
    for (const item of parsed) {
      const rule = ruleByCode.get(item.ruleCode);
      if (!rule) continue; // ignore hallucinated rule codes defensively
      const result = await this.prisma.complianceResult.create({
        data: {
          contractId,
          ruleId: rule.id,
          status: item.status,
          evidence: item.evidence,
          recommendation: item.recommendation ?? null,
        },
      });
      created.push(result);
    }

    const failCount = created.filter((r) => r.status === 'FAIL').length;
    if (failCount > 0) {
      await this.notifications.create({
        organizationId: orgId,
        type: 'COMPLIANCE_FAILED',
        title: `"${contract.title}" failed ${failCount} ${framework.name} check(s)`,
        message: `Run the ${framework.name} compliance check on this contract to see what needs to change.`,
        metadata: { contractId, frameworkCode },
      });
    }

    return created;
  }
}
