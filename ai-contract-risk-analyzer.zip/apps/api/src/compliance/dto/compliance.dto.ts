import { IsString, IsArray, ValidateNested, ArrayMinSize } from 'class-validator';
import { Type } from 'class-transformer';

export class RunComplianceCheckDto {
  @IsString()
  frameworkCode: string;
}

export class CustomRuleDto {
  @IsString()
  code: string;

  @IsString()
  description: string;
}

export class CreateCustomFrameworkDto {
  @IsString()
  code: string;

  @IsString()
  name: string;

  @IsString()
  description: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => CustomRuleDto)
  rules: CustomRuleDto[];
}
