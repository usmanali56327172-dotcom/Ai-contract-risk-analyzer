import { Controller, Get, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ComplianceService } from './compliance.service';
import { RunComplianceCheckDto, CreateCustomFrameworkDto } from './dto/compliance.dto';

@Controller()
@UseGuards(JwtAuthGuard)
export class ComplianceController {
  constructor(private readonly complianceService: ComplianceService) {}

  @Get('compliance/frameworks')
  listFrameworks(@Req() req: any) {
    return this.complianceService.listFrameworks(req.user.orgId);
  }

  @Post('compliance/frameworks')
  createFramework(@Req() req: any, @Body() dto: CreateCustomFrameworkDto) {
    return this.complianceService.createCustomFramework(req.user.orgId, dto);
  }

  @Get('contracts/:contractId/compliance')
  getResults(@Param('contractId') contractId: string) {
    return this.complianceService.getResultsForContract(contractId);
  }

  @Post('contracts/:contractId/compliance/check')
  runCheck(@Req() req: any, @Param('contractId') contractId: string, @Body() dto: RunComplianceCheckDto) {
    return this.complianceService.runCheck(req.user.orgId, contractId, dto.frameworkCode);
  }
}
