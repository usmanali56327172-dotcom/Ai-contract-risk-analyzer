export function buildComplianceCheckPrompt(params: {
  frameworkName: string;
  rules: { code: string; description: string }[];
  contractText: string;
}): string {
  const { frameworkName, rules, contractText } = params;
  return `You are a compliance analyst checking a contract against ${frameworkName} requirements.

For EACH of the following rules, determine whether the contract text satisfies it. Return ONLY
valid JSON (no markdown fences, no preamble) as an array, one object per rule, in the same order,
matching exactly:

[
  {
    "ruleCode": string (must match one of the rule codes given below exactly),
    "status": "PASS" | "FAIL" | "PARTIAL" | "NOT_APPLICABLE",
    "evidence": string (quote or closely paraphrase the relevant contract language, or state "No relevant language found" if absent),
    "recommendation": string | null (specific language or clause to add/fix if status is FAIL or PARTIAL; null if PASS or NOT_APPLICABLE)
  }
]

Rules to check:
${rules.map((r) => `- [${r.code}] ${r.description}`).join('\n')}

CONTRACT TEXT:
"""
${contractText.slice(0, 100000)}
"""`;
}
