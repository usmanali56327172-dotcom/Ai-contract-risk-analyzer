export function buildExpiryPrompt(contractText: string): string {
  return `You are a contract-management analyst. Read the contract below and extract its key dates
and renewal mechanics. Return ONLY valid JSON (no markdown fences, no preamble) matching exactly:

{
  "effectiveDate": string | null (ISO 8601 date, e.g. "2024-03-01"),
  "expiryDate": string | null (ISO 8601 date; if the contract has a fixed term, compute the end date from the effective date + term length if an explicit expiry date isn't stated),
  "renewalType": "AUTO_RENEW" | "MANUAL_RENEW" | "FIXED_TERM" | "EVERGREEN" | "UNKNOWN",
  "autoRenew": boolean,
  "noticePeriodDays": number | null (days of advance notice required to terminate/not renew, if stated),
  "extractionNotes": string (briefly note any ambiguity or assumptions you made, in English)
}

If a date or fact truly cannot be determined from the text, use null rather than guessing.

CONTRACT TEXT:
"""
${contractText.slice(0, 100000)}
"""`;
}
