import { Injectable, NotFoundException, InternalServerErrorException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { buildExpiryPrompt } from './expiry.prompts';

function parseJsonResponse(raw: string) {
  const cleaned = raw.replace(/^```json\s*/i, '').replace(/```$/, '').trim();
  return JSON.parse(cleaned);
}

@Injectable()
export class ExpiryService {
  private readonly logger = new Logger(ExpiryService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  private withDaysUntilExpiry(record: any) {
    if (!record) return record;
    const daysUntilExpiry = record.expiryDate
      ? Math.ceil((new Date(record.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      : null;
    return { ...record, daysUntilExpiry };
  }

  async getForContract(contractId: string) {
    const record = await this.prisma.contractDates.findUnique({ where: { contractId } });
    return this.withDaysUntilExpiry(record);
  }

  async extractForContract(orgId: string, contractId: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: { versions: { orderBy: { versionNum: 'desc' }, take: 1 } },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }

    const text = contract.versions[0]?.extractedText;
    if (!text) throw new NotFoundException('No extracted text found for this contract');

    const prompt = buildExpiryPrompt(text);

    let response;
    try {
      response = await this.client.responses.create({ model: this.model, input: prompt, temperature: 0 });
    } catch (err) {
      this.logger.error('Expiry extraction call failed', err as Error);
      throw new InternalServerErrorException('AI expiry-extraction provider error');
    }

    let parsed: any;
    try {
      parsed = parseJsonResponse(response.output_text ?? '');
    } catch (err) {
      this.logger.error('Failed to parse expiry response', err as Error);
      throw new InternalServerErrorException('AI expiry response could not be parsed');
    }

    const record = await this.prisma.contractDates.upsert({
      where: { contractId },
      create: {
        contractId,
        effectiveDate: parsed.effectiveDate ? new Date(parsed.effectiveDate) : null,
        expiryDate: parsed.expiryDate ? new Date(parsed.expiryDate) : null,
        renewalType: parsed.renewalType ?? 'UNKNOWN',
        autoRenew: !!parsed.autoRenew,
        noticePeriodDays: parsed.noticePeriodDays ?? null,
        extractionNotes: parsed.extractionNotes ?? null,
      },
      update: {
        effectiveDate: parsed.effectiveDate ? new Date(parsed.effectiveDate) : null,
        expiryDate: parsed.expiryDate ? new Date(parsed.expiryDate) : null,
        renewalType: parsed.renewalType ?? 'UNKNOWN',
        autoRenew: !!parsed.autoRenew,
        noticePeriodDays: parsed.noticePeriodDays ?? null,
        extractionNotes: parsed.extractionNotes ?? null,
      },
    });

    return this.withDaysUntilExpiry(record);
  }

  /** Org-wide list of contracts expiring within N days, soonest first. */
  async listExpiringSoon(orgId: string, withinDays: number) {
    const cutoff = new Date(Date.now() + withinDays * 24 * 60 * 60 * 1000);
    const records = await this.prisma.contractDates.findMany({
      where: {
        expiryDate: { lte: cutoff, gte: new Date() },
        contract: { organizationId: orgId },
      },
      include: { contract: { select: { id: true, title: true, status: true } } },
      orderBy: { expiryDate: 'asc' },
    });
    return records.map((r: any) => this.withDaysUntilExpiry(r));
  }
}
