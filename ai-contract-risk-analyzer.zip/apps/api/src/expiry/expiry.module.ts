import { Module } from '@nestjs/common';
import { ExpiryController } from './expiry.controller';
import { ExpiryService } from './expiry.service';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [AuthModule],
  controllers: [ExpiryController],
  providers: [ExpiryService],
  exports: [ExpiryService],
})
export class ExpiryModule {}
