import { Controller, Get, Post, Param, Query, Req, UseGuards, DefaultValuePipe, ParseIntPipe } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ExpiryService } from './expiry.service';

@Controller()
@UseGuards(JwtAuthGuard)
export class ExpiryController {
  constructor(private readonly expiryService: ExpiryService) {}

  // NOTE: registered ahead of ContractsController's GET /contracts/:id via module
  // import order in app.module.ts, but kept on a distinct path prefix regardless
  // so route matching can never be ambiguous between "expiring" and a contract id.
  @Get('expiry/expiring-soon')
  expiringSoon(
    @Req() req: any,
    @Query('withinDays', new DefaultValuePipe(30), ParseIntPipe) withinDays: number,
  ) {
    return this.expiryService.listExpiringSoon(req.user.orgId, withinDays);
  }

  @Get('contracts/:contractId/dates')
  get(@Param('contractId') contractId: string) {
    return this.expiryService.getForContract(contractId);
  }

  @Post('contracts/:contractId/dates/extract')
  extract(@Req() req: any, @Param('contractId') contractId: string) {
    return this.expiryService.extractForContract(req.user.orgId, contractId);
  }
}
