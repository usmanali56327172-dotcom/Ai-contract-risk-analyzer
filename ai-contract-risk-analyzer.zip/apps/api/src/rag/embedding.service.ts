import { Injectable, Logger, InternalServerErrorException, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { QdrantClient } from '@qdrant/js-client-rest';
import * as crypto from 'crypto';
import { chunkText } from './text-chunking.util';

const EMBEDDING_MODEL = 'text-embedding-3-small';
const EMBEDDING_DIMENSIONS = 1536; // text-embedding-3-small output size
const COLLECTION_NAME = 'contract_chunks';

/**
 * Vector storage for RAG chat, backed by Qdrant rather than Postgres + in-Node cosine similarity.
 * This is the piece that was called out in PROGRESS.md as not scaling past a single contract's
 * worth of chunks — Qdrant does the nearest-neighbor search instead of scanning every stored
 * vector in application code, so this scales to many contracts' worth of chunks per org.
 */
@Injectable()
export class EmbeddingService implements OnModuleInit {
  private readonly logger = new Logger(EmbeddingService.name);
  private readonly openai: OpenAI;
  private readonly qdrant: QdrantClient;

  constructor(private readonly config: ConfigService) {
    this.openai = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.qdrant = new QdrantClient({
      url: this.config.get<string>('QDRANT_URL', 'http://localhost:6333'),
      apiKey: this.config.get<string>('QDRANT_API_KEY') || undefined,
      checkCompatibility: false,
    });
  }

  /** Creates the shared collection on boot if it doesn't already exist. Idempotent. */
  async onModuleInit(): Promise<void> {
    try {
      const collections = await this.qdrant.getCollections();
      const exists = collections.collections.some((c) => c.name === COLLECTION_NAME);
      if (!exists) {
        await this.qdrant.createCollection(COLLECTION_NAME, {
          vectors: { size: EMBEDDING_DIMENSIONS, distance: 'Cosine' },
        });
        this.logger.log(`Created Qdrant collection "${COLLECTION_NAME}"`);
      }
    } catch (err) {
      // Don't crash the whole API if Qdrant isn't up yet — chat features will fail clearly
      // when actually used instead, which is easier to diagnose than a boot-time crash loop.
      this.logger.error(
        `Could not reach Qdrant at boot — RAG chat will fail until it's reachable. ` +
          `Check QDRANT_URL and that the Qdrant container is running.`,
        err as Error,
      );
    }
  }

  private async embed(input: string | string[]): Promise<number[][]> {
    try {
      const response = await this.openai.embeddings.create({ model: EMBEDDING_MODEL, input });
      return response.data.map((d) => d.embedding);
    } catch (err) {
      this.logger.error('Embedding generation failed', err as Error);
      throw new InternalServerErrorException('Embedding provider error');
    }
  }

  /** Generates and stores embeddings for a contract in Qdrant if not already present. Idempotent. */
  async ensureEmbeddings(contractId: string, fullText: string): Promise<void> {
    const existing = await this.qdrant.count(COLLECTION_NAME, {
      filter: { must: [{ key: 'contractId', match: { value: contractId } }] },
    });
    if (existing.count > 0) return;

    const chunks = chunkText(fullText);
    const vectors = await this.embed(chunks);

    try {
      await this.qdrant.upsert(COLLECTION_NAME, {
        wait: true,
        points: chunks.map((chunkTextValue, i) => ({
          id: crypto.randomUUID(),
          vector: vectors[i],
          payload: { contractId, chunkIndex: i, chunkText: chunkTextValue },
        })),
      });
    } catch (err) {
      this.logger.error('Qdrant upsert failed', err as Error);
      throw new InternalServerErrorException(
        'Vector store is unreachable. Make sure Qdrant is running (docker compose up -d qdrant).',
      );
    }
  }

  /** Returns the top-K most relevant chunks for a query, ranked by Qdrant's nearest-neighbor search. */
  async retrieveRelevantChunks(contractId: string, query: string, topK = 5): Promise<string[]> {
    const [queryVector] = await this.embed(query);

    let results;
    try {
      results = await this.qdrant.search(COLLECTION_NAME, {
        vector: queryVector,
        limit: topK,
        filter: { must: [{ key: 'contractId', match: { value: contractId } }] },
        with_payload: true,
      });
    } catch (err) {
      this.logger.error('Qdrant search failed', err as Error);
      throw new InternalServerErrorException(
        'Vector store is unreachable. Make sure Qdrant is running (docker compose up -d qdrant).',
      );
    }

    return results.map((r) => (r.payload as any).chunkText as string);
  }
}
