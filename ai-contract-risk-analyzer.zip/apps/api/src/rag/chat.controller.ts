import { Controller, Get, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ChatService } from './chat.service';
import { AskContractDto } from './dto/chat.dto';

@Controller('contracts/:contractId/chat')
@UseGuards(JwtAuthGuard)
export class ChatController {
  constructor(private readonly chatService: ChatService) {}

  @Get()
  history(@Param('contractId') contractId: string) {
    return this.chatService.getHistory(contractId);
  }

  @Post()
  ask(@Req() req: any, @Param('contractId') contractId: string, @Body() dto: AskContractDto) {
    return this.chatService.ask(req.user.orgId, contractId, req.user.sub, dto.question);
  }
}
