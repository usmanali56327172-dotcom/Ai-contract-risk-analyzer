import { chunkText } from './text-chunking.util';

describe('chunkText', () => {
  it('returns a single chunk when text is shorter than chunkSize', () => {
    const chunks = chunkText('short text', 1200, 150);
    expect(chunks).toEqual(['short text']);
  });

  it('splits long text into multiple overlapping chunks', () => {
    const text = 'a'.repeat(3000);
    const chunks = chunkText(text, 1200, 150);

    expect(chunks.length).toBeGreaterThan(1);
    // every chunk except the last should be exactly chunkSize long
    for (const chunk of chunks.slice(0, -1)) {
      expect(chunk.length).toBe(1200);
    }
  });

  it('produces overlapping content between consecutive chunks', () => {
    const text = 'a'.repeat(1200) + 'b'.repeat(1200);
    const chunks = chunkText(text, 1200, 150);

    // the end of chunk 0 and the start of chunk 1 should share the overlap region
    const overlapFromChunk0 = chunks[0].slice(-150);
    const overlapFromChunk1 = chunks[1].slice(0, 150);
    expect(overlapFromChunk0).toBe(overlapFromChunk1);
  });

  it('covers the entire input text with no gaps', () => {
    const text = 'The quick brown fox jumps over the lazy dog. '.repeat(100);
    const chunks = chunkText(text, 200, 30);
    const reconstructed = chunks.reduce((acc, chunk, i) => {
      if (i === 0) return chunk;
      // drop the overlapping prefix before appending
      return acc + chunk.slice(30);
    }, '');
    expect(reconstructed).toBe(text);
  });
});
