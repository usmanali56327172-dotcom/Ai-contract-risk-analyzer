import { IsString, MinLength } from 'class-validator';

export class AskContractDto {
  @IsString()
  @MinLength(1)
  question: string;
}
