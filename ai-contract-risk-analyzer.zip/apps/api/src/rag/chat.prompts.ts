export function buildChatPrompt(params: {
  contractTitle: string;
  relevantChunks: string[];
  history: { role: 'USER' | 'ASSISTANT'; content: string }[];
  question: string;
}): string {
  const { contractTitle, relevantChunks, history, question } = params;

  const historyText = history
    .slice(-6)
    .map((m) => `${m.role === 'USER' ? 'User' : 'Assistant'}: ${m.content}`)
    .join('\n');

  return `You are a contract Q&A assistant. Answer the user's question about the contract
"${contractTitle}" using ONLY the excerpts provided below. If the excerpts don't contain the
answer, say so clearly rather than guessing or inventing contract language.

RELEVANT CONTRACT EXCERPTS:
"""
${relevantChunks.join('\n---\n')}
"""

${historyText ? `RECENT CONVERSATION:\n${historyText}\n` : ''}

USER QUESTION:
${question}

Answer concisely and cite the specific clause or section when possible. Do not fabricate clauses
that aren't in the excerpts above.`;
}
