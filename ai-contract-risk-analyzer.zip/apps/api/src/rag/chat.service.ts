import { Injectable, NotFoundException, InternalServerErrorException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { EmbeddingService } from './embedding.service';
import { buildChatPrompt } from './chat.prompts';

@Injectable()
export class ChatService {
  private readonly logger = new Logger(ChatService.name);
  private readonly client: OpenAI;
  private readonly model: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly embeddings: EmbeddingService,
  ) {
    this.client = new OpenAI({ apiKey: this.config.get<string>('OPENAI_API_KEY') });
    this.model = this.config.get<string>('OPENAI_MODEL', 'gpt-4.1');
  }

  async getHistory(contractId: string) {
    return this.prisma.chatMessage.findMany({
      where: { contractId },
      orderBy: { createdAt: 'asc' },
    });
  }

  async ask(orgId: string, contractId: string, userId: string, question: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: { versions: { orderBy: { versionNum: 'desc' }, take: 1 } },
    });
    if (!contract || contract.organizationId !== orgId) {
      throw new NotFoundException('Contract not found');
    }

    const text = contract.versions[0]?.extractedText;
    if (!text) throw new NotFoundException('No extracted text found for this contract');

    // Lazily build embeddings the first time someone chats with this contract.
    await this.embeddings.ensureEmbeddings(contractId, text);

    const relevantChunks = await this.embeddings.retrieveRelevantChunks(contractId, question, 5);

    const history = await this.getHistory(contractId);

    const prompt = buildChatPrompt({
      contractTitle: contract.title,
      relevantChunks,
      history: history.map((h: any) => ({ role: h.role as 'USER' | 'ASSISTANT', content: h.content })),
      question,
    });

    let response;
    try {
      response = await this.client.responses.create({ model: this.model, input: prompt, temperature: 0.2 });
    } catch (err) {
      this.logger.error('Chat completion call failed', err as Error);
      throw new InternalServerErrorException('AI chat provider error');
    }

    const answer = response.output_text?.trim() ?? '';

    await this.prisma.$transaction([
      this.prisma.chatMessage.create({
        data: { contractId, userId, role: 'USER', content: question },
      }),
      this.prisma.chatMessage.create({
        data: { contractId, userId, role: 'ASSISTANT', content: answer },
      }),
    ]);

    return { answer, sourceChunks: relevantChunks };
  }
}
