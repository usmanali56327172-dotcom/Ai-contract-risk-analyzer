import { Controller, Get, Post, Delete, Param, Body, Query, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ClauseTemplateService } from './clause-template.service';
import { CreateClauseTemplateDto } from './dto/clause-template.dto';

@Controller('clause-templates')
@UseGuards(JwtAuthGuard)
export class ClauseTemplateController {
  constructor(private readonly service: ClauseTemplateService) {}

  @Get()
  list(@Req() req: any, @Query('clauseType') clauseType?: string) {
    return this.service.list(req.user.orgId, clauseType);
  }

  @Post()
  create(@Req() req: any, @Body() dto: CreateClauseTemplateDto) {
    return this.service.create(req.user.orgId, req.user.sub, dto);
  }

  @Get(':id')
  getOne(@Req() req: any, @Param('id') id: string) {
    return this.service.getOne(req.user.orgId, id);
  }

  @Post(':id/use')
  use(@Req() req: any, @Param('id') id: string) {
    return this.service.recordUsage(req.user.orgId, id);
  }

  @Delete(':id')
  delete(@Req() req: any, @Param('id') id: string) {
    return this.service.delete(req.user.orgId, id);
  }
}
