import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateClauseTemplateDto } from './dto/clause-template.dto';

@Injectable()
export class ClauseTemplateService {
  constructor(private readonly prisma: PrismaService) {}

  async list(orgId: string, clauseType?: string) {
    return this.prisma.clauseTemplate.findMany({
      where: { organizationId: orgId, ...(clauseType ? { clauseType } : {}) },
      orderBy: [{ usageCount: 'desc' }, { updatedAt: 'desc' }],
    });
  }

  async create(orgId: string, userId: string, dto: CreateClauseTemplateDto) {
    return this.prisma.clauseTemplate.create({
      data: {
        organizationId: orgId,
        clauseType: dto.clauseType,
        title: dto.title,
        content: dto.content,
        tags: dto.tags ?? [],
        createdById: userId,
      },
    });
  }

  async getOne(orgId: string, id: string) {
    const template = await this.prisma.clauseTemplate.findUnique({ where: { id } });
    if (!template) throw new NotFoundException('Clause template not found');
    if (template.organizationId !== orgId) throw new ForbiddenException('Not your organization');
    return template;
  }

  /** Marks a template as used, incrementing its popularity counter. */
  async recordUsage(orgId: string, id: string) {
    await this.getOne(orgId, id); // ownership check
    return this.prisma.clauseTemplate.update({
      where: { id },
      data: { usageCount: { increment: 1 } },
    });
  }

  async delete(orgId: string, id: string) {
    await this.getOne(orgId, id); // ownership check
    await this.prisma.clauseTemplate.delete({ where: { id } });
    return { deleted: true };
  }
}
