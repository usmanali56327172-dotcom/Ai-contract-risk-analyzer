import { IsString, IsArray, IsOptional } from 'class-validator';

export class CreateClauseTemplateDto {
  @IsString()
  clauseType: string;

  @IsString()
  title: string;

  @IsString()
  content: string;

  @IsArray()
  @IsOptional()
  tags?: string[];
}

export class SaveClauseFromContractDto {
  @IsString()
  clauseType: string;

  @IsString()
  title: string;

  @IsString()
  content: string;
}
