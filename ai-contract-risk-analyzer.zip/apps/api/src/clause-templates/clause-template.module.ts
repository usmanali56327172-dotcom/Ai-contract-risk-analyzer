import { Module } from '@nestjs/common';
import { ClauseTemplateController } from './clause-template.controller';
import { ClauseTemplateService } from './clause-template.service';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [AuthModule],
  controllers: [ClauseTemplateController],
  providers: [ClauseTemplateService],
})
export class ClauseTemplateModule {}
