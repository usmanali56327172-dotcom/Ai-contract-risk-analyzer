# PROGRESS.md — AI Contract Risk Analyzer

This file tracks what is **actually implemented and working** in this delivery, so future
sessions can continue building instead of re-explaining scope every time. The original 10-phase
spec's full roadmap has now been worked through — see the honesty notes near the end for the
handful of things that are genuinely gated behind external accounts/credentials rather than
sandbox effort.

## ✅ Implemented and verified

- **Monorepo**: pnpm + Turborepo, `apps/api` (NestJS), `apps/web` (Next.js 15), `packages/db` (Prisma)
- **Database schema**: Organization, User, Membership (RBAC), RefreshToken, Contract,
  ContractVersion, ClauseLibrary, AIReport, RiskScore, ActivityLog, Notification, Subscription,
  ContractComparison/ComparisonClauseDiff, plus every feature model listed below
- **Auth**: register (creates org + owner), login, refresh-token rotation (SHA-256 hashed,
  single-use, 30-day expiry), JWT access tokens (15 min), `JwtAuthGuard`, `RolesGuard` + `@Roles()`,
  **Google + Microsoft OAuth** (Passport strategies; logs in an existing user by email or
  auto-creates a personal org for a new one — see honesty note on live-testing below)
- **Document ingestion**: PDF text extraction (`pdf-parse`), DOCX text extraction (`mammoth`),
  automatic **OCR fallback** for scanned/image-only PDFs (`tesseract.js` + `pdf-to-png-converter`,
  no native Tesseract binary needed) — verified end-to-end in this sandbox with a synthetic
  scanned PDF, correctly recovering text at 95% confidence
- **AI analysis engine**: OpenAI Responses API, structured JSON-only prompt covering all 12
  clause types, missing-clause detection, 4-dimension risk scoring, executive summary,
  recommendations, confidence score, prompt versioning, **multi-language** (detects and analyzes
  the contract's original language, normalizes output to English)
- **AI Redline Generator**, **AI Negotiation Assistant**, **Contract Expiry Prediction**,
  **Compliance Checker** (built-in GDPR/HIPAA/ISO 27001 + custom org frameworks), **AI Chat /
  RAG** (chunked, embedded with `text-embedding-3-small`, stored and searched in **Qdrant** —
  verified against a real running Qdrant instance in this sandbox), **Risk Trend Dashboard**,
  **Clause Library**, **Contract Comparison & clause diffing** — see prior session notes below
  for the detailed verification story on each
- **Async analysis pipeline**: BullMQ, Redis-backed, 3 retries w/ exponential backoff, and the
  worker is its own deployable process (`apps/api/src/worker.ts`) separate from the HTTP API —
  verified booting both against real Redis in this sandbox
- **E-signature**: adapter pattern, fully working `manual` provider, honestly-stubbed `docusign`
  provider that fails loudly with exact setup instructions rather than faking success
- **PDF/DOCX export** (`apps/api/src/export`): generates a real report (risk scores, executive
  summary, clauses, missing clauses, recommendations) as a downloadable PDF (`pdfkit`) or DOCX
  (`docx`) file. **Verified in this sandbox**: generated both from a fake AI report through the
  actual compiled `ExportService`, confirmed valid file headers (`%PDF-` / `PK` ZIP signature) —
  not just that it compiled.
- **Notifications** (`apps/api/src/notifications`): in-app notifications for contract-analyzed,
  contract-expiring (a daily `@nestjs/schedule` cron job, `notifiedExpiringSoon` flag prevents
  duplicates), compliance-check failures, e-signature completion, comparison completion, and
  billing updates. Bell icon + unread count + panel in the shared `AppHeader`. The cron job
  deliberately only runs in the API process, not the worker, so it can't fire twice.
- **Billing/Stripe** (`apps/api/src/billing`): Stripe customer creation, Checkout Session
  (subscribe), Billing Portal Session (manage/cancel), and a webhook handler that verifies Stripe's
  signature and syncs `Subscription` status from `checkout.session.completed` /
  `customer.subscription.updated` / `.deleted`. **Verified in this sandbox**: webhook signature
  verification is pure local HMAC (no network call), so I generated a real signed test event with
  the actual `stripe` SDK and confirmed both correct parsing of a valid signature *and* correct
  rejection of a tampered one, through the real compiled `BillingService`. `/billing` page in the
  frontend shows plan/status and triggers checkout/portal redirects.
- **Docker**: multi-stage `Dockerfile` for the API (same image serves API and worker via a
  command override) and for the web app (Next.js standalone output), wired into
  `docker-compose.yml` alongside Postgres/Redis/Qdrant.
- **CI**: `.github/workflows/ci.yml` — installs, generates the Prisma client, lints, typechecks +
  builds both apps, runs the test suite, then builds both Docker images, on every push/PR.
- **Tests**: 27 real Jest unit tests, all passing — `AuthService` (registration, login, refresh
  rotation, OAuth login/register, bcrypt hashing verified not-plaintext), risk-level
  classification, RAG text chunking (overlap + full-coverage correctness), the analysis and
  comparison prompt builders. Run with `pnpm --filter @acra/api test`.
- **Frontend**: login/register (+ OAuth buttons), `/oauth-callback`, dashboard, upload, contract
  detail (AI Report / Redlines / Negotiation / Expiry / Compliance / Chat / E-Signature tabs, PDF/
  DOCX export buttons), `/analytics`, `/clause-library`, `/compare` + `/compare/[id]`, `/billing`,
  notification bell in the shared header. "Ink & Brass" design system (see below).
- **Security baseline**: Helmet, global ValidationPipe, rate limiting, bcrypt (cost 12)

Both `apps/api` (`nest build` + `tsc --noEmit`) and `apps/web` (`next build`, all 13 routes) run
clean with zero TypeScript errors as of this session.

## Honesty notes — what's genuinely untestable here vs. what's a real gap

Some things in this last batch of features fundamentally require a live external network call to
a provider this sandbox's network allowlist doesn't include (OpenAI, Stripe's live API, Google/
Microsoft's OAuth consent screens) or a real third-party developer account (DocuSign, actual
Stripe/OAuth app credentials). Where that's true, I tested everything *around* that boundary as
rigorously as I could and I'm naming the boundary precisely rather than glossing over it:

- **Stripe**: webhook signature verification and event handling were verified live (see above,
  no network needed — it's HMAC). Checkout Session / Portal Session / Customer creation call the
  real Stripe API (`api.stripe.com`), which isn't reachable from this sandbox, so those three
  calls are correct against the real SDK's types but not live-tested here. Anyone can get a free
  Stripe test-mode account to verify this end — it's not gated like DocuSign is.
- **Google/Microsoft OAuth**: the strategies, controller routes, and `loginOrRegisterOAuth`
  business logic (login-vs-register branching, unusable-password hashing) are unit-tested. The
  actual OAuth handshake against `accounts.google.com` / `login.microsoftonline.com` needs real
  client ID/secret from a registered OAuth app and isn't reachable from this sandbox either. Both
  strategies default to a `'not-configured'` placeholder so the app still boots cleanly without
  these set — the routes just fail clearly if actually hit unconfigured.
- **Docker builds**: no Docker daemon is available in this sandbox (`docker: not found`), so
  `docker build` / `docker compose up` themselves were not run here. Every command *inside* the
  Dockerfiles (`pnpm install`, `prisma generate`, `nest build`, `next build`) was independently
  verified working in this exact codebase during this session, just not through the Docker layer
  itself. Validate with `docker compose up --build` before relying on this in production.
- **DocuSign**: unchanged from before — genuinely requires a DocuSign developer account, so the
  adapter fails loudly with exact setup instructions instead of faking success.
- **OCR language coverage**: only English (`eng`) ships by default. `pnpm add
  @tesseract.js-data/<lang>` + `OCR_LANGUAGE=<lang>` adds another — no code change needed.

## ⚠️ Known sandbox constraint (not a code bug)

`prisma generate` cannot download its query-engine binary in this sandbox
(`binaries.prisma.sh` returns 403 — the sandbox's network allowlist doesn't include it). This is
an environment restriction, not a schema or code problem — it works normally in the CI workflow
above and on a real machine. If you hit this in another restricted sandbox, set
`PRISMA_ENGINES_CHECKSUM_IGNORE_MISSING=1` and vendor the engine binary, or switch to
`driverAdapters` with `@prisma/adapter-pg` to avoid the native engine entirely.

## Design system — "Ink & Brass"

The frontend moved off the generic dark-slate + indigo palette most AI-generated SaaS UIs
converge on, to a deliberate identity fitted to the product: warm near-black ink backgrounds, a
brass/gold accent (wax-seal/gold-foil association) reserved for brand + primary actions (risk
keeps its own red/amber/emerald semantic system, untouched), Fraunces for headings, IBM Plex Sans
for body, IBM Plex Mono for data figures. The landing hero's signature element is an actual
redline mockup built from the real Redline Generator feature. The palette swap was done once, in
`tailwind.config.ts` (overriding the `slate` and `indigo` scales), so the whole app inherited it
without per-component edits.

## What's left (genuinely, not as a hedge)

- **Team collaboration** beyond basic org membership (comments, shared workspaces)
- **Contract version diffing UI** (schema supports multiple versions; UI only shows the latest)
- **Audit-log / activity-timeline UI** (the `ActivityLog` table exists; no frontend for it)
- **Integration/E2E tests** (unit tests exist and pass; nothing yet drives a live Postgres/Redis
  through the API's HTTP layer end-to-end)
- **Kubernetes/Terraform, production monitoring, AWS deployment** specifics
- Everything named in the honesty notes above once you have the relevant credentials
